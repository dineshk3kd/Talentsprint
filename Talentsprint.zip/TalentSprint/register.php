<?php
session_start();

require_once __DIR__ . '/config/database.php';

$data = db_load();

$error = '';
$success = '';

$name = '';
$email = '';
$role = 'student';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = (string) ($_POST['password'] ?? '');
    $role = $_POST['role'] ?? 'student';

    if ($name === '' || $email === '' || $password === '') {
        $error = 'Please fill in all required fields.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';

    } elseif (strlen($password) < 6) {
        $error = 'Password must contain at least 6 characters.';

    } elseif (!in_array($role, ['student', 'company'], true)) {
        $error = 'Please select a valid account type.';

    } elseif (db_find_user_by_email($data, $email)) {
        $error = 'An account with this email already exists.';

    } else {

        $userId = db_next_id($data, 'users');

        $data['users'][] = [
            'id' => $userId,
            'name' => $name,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'role' => $role,
            'created_at' => db_now()
        ];

        if ($role === 'student') {

            $data['students'][] = [
                'id' => db_next_id($data, 'students'),
                'user_id' => $userId,
                'phone' => '',
                'college' => '',
                'course' => '',
                'skills' => '',
                'bio' => '',
                'resume' => ''
            ];

        } else {

            $data['companies'][] = [
                'id' => db_next_id($data, 'companies'),
                'user_id' => $userId,
                'company_name' => $name,
                'website' => '',
                'description' => ''
            ];
        }

        if (db_save($data)) {

            $success = 'Account created successfully. You can now sign in.';

            $name = '';
            $email = '';
            $role = 'student';

        } else {

            $error = 'Unable to save the account. Please check folder permissions.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta
        name="description"
        content="Create your TalentSprint account to discover internships and build your professional future."
    >

    <title>Create Account | TalentSprint</title>

    <link rel="stylesheet" href="css/style.css">

    <style>
        /* ==========================================
           TALENTSPRINT REGISTRATION PAGE
           All styles are scoped to this page.
        ========================================== */

        html {
            min-height: 100%;
            overflow-x: hidden;
            overflow-y: auto;
            scroll-behavior: smooth;
        }

        body.rocket-register {
            --rocket-cyan: #00d9ff;
            --rocket-blue: #3185ff;
            --rocket-purple: #a855f7;
            --rocket-text: #f5f7ff;
            --rocket-muted: #aebee9;

            width: 100%;
            min-height: 100vh;
            height: auto !important;

            margin: 0;
            padding: 25px 5% 45px;

            position: relative;

            overflow-x: hidden !important;
            overflow-y: auto !important;

            isolation: isolate;

            color: var(--rocket-text);
            font-family: "Segoe UI", Arial, sans-serif;

            background:
                radial-gradient(
                    ellipse at 12% 85%,
                    rgba(26, 65, 255, 0.38),
                    transparent 40%
                ),
                radial-gradient(
                    ellipse at 90% 10%,
                    rgba(145, 35, 255, 0.35),
                    transparent 38%
                ),
                linear-gradient(
                    135deg,
                    #020821 0%,
                    #07154a 52%,
                    #180c45 100%
                );
        }

        .rocket-register *,
        .rocket-register *::before,
        .rocket-register *::after {
            box-sizing: border-box;
        }

        .rocket-register a {
            -webkit-tap-highlight-color: transparent;
        }

        /* Background glows */

        .rocket-register .space-glow {
            position: absolute;
            z-index: -1;

            width: 360px;
            height: 360px;

            border-radius: 50%;

            filter: blur(100px);
            opacity: .25;

            pointer-events: none;

            animation: rocketSpaceGlow 12s ease-in-out infinite alternate;
        }

        .rocket-register .glow-left {
            left: -180px;
            bottom: 0;
            background: #075dff;
        }

        .rocket-register .glow-right {
            right: -180px;
            top: 0;
            background: #bc38ff;
            animation-delay: -5s;
        }

        @keyframes rocketSpaceGlow {
            from {
                transform: translate(0, 0) scale(1);
            }

            to {
                transform: translate(45px, -35px) scale(1.2);
            }
        }

        /* Stars */

        .rocket-register .stars {
            position: absolute;
            inset: 0;

            z-index: -1;

            overflow: hidden;
            pointer-events: none;
        }

        .rocket-register .star {
            position: absolute;

            width: 3px;
            height: 3px;

            border-radius: 50%;

            background: white;

            box-shadow: 0 0 12px 3px rgba(80, 190, 255, .6);

            animation: rocketTwinkle 2.5s ease-in-out infinite alternate;
        }

        .rocket-register .star:nth-child(1) {
            left: 8%;
            top: 15%;
        }

        .rocket-register .star:nth-child(2) {
            left: 34%;
            top: 10%;
            animation-delay: .8s;
        }

        .rocket-register .star:nth-child(3) {
            left: 45%;
            top: 34%;
            animation-delay: 1.2s;
        }

        .rocket-register .star:nth-child(4) {
            left: 12%;
            top: 65%;
            animation-delay: .5s;
        }

        .rocket-register .star:nth-child(5) {
            left: 40%;
            top: 72%;
            animation-delay: 1.6s;
        }

        .rocket-register .star:nth-child(6) {
            right: 10%;
            top: 20%;
            animation-delay: .3s;
        }

        .rocket-register .star:nth-child(7) {
            right: 35%;
            top: 82%;
            animation-delay: 1s;
        }

        .rocket-register .star:nth-child(8) {
            left: 25%;
            top: 45%;
            animation-delay: .7s;
        }

        @keyframes rocketTwinkle {
            from {
                opacity: .25;
                transform: scale(.7);
            }

            to {
                opacity: 1;
                transform: scale(1.5);
            }
        }

        /* Header */

        .rocket-register .rocket-header {
            width: 100%;
            max-width: 1450px;

            margin: 0 auto;

            display: flex;
            justify-content: space-between;
            align-items: center;

            gap: 20px;

            position: relative;
            z-index: 5;
        }

        .rocket-register .rocket-logo {
            text-decoration: none;
            color: white;

            font-size: clamp(24px, 3vw, 35px);
            font-weight: 850;
            letter-spacing: -1.5px;

            flex-shrink: 0;
        }

        .rocket-register .rocket-logo span {
            background: linear-gradient(
                90deg,
                #00d9ff,
                #438cff,
                #bd63ff
            );

            -webkit-background-clip: text;
            background-clip: text;

            color: transparent;
        }

        .rocket-register .header-login {
            display: flex;
            align-items: center;
            justify-content: flex-end;

            gap: 20px;

            color: #c9d5f5;
            font-size: 14px;
        }

        .rocket-register .header-login a {
            text-decoration: none;
            color: white;

            padding: 11px 26px;

            border: 1px solid #747bff;
            border-radius: 30px;

            white-space: nowrap;

            transition:
                background .3s,
                transform .3s,
                border-color .3s;
        }

        .rocket-register .header-login a:hover {
            background: rgba(113, 83, 255, .2);
            border-color: var(--rocket-cyan);
            transform: translateY(-2px);
        }

        /* Main layout */

        .rocket-register .rocket-layout {
            width: 100%;
            max-width: 1450px;

            margin: 35px auto 0;

            display: grid;

            grid-template-columns:
                minmax(0, 1.05fr)
                minmax(0, .95fr);

            gap: clamp(35px, 5vw, 85px);

            align-items: center;
        }

        /* Left introduction */

        .rocket-register .rocket-intro {
            position: relative;
            min-width: 0;

            padding: 35px 0;
        }

        .rocket-register .intro-label {
            display: inline-flex;
            align-items: center;

            gap: 10px;

            padding: 9px 15px;
            margin-bottom: 24px;

            border: 1px solid rgba(0, 217, 255, .3);
            border-radius: 30px;

            background: rgba(0, 217, 255, .07);

            color: #63e9ff;

            font-size: 11px;
            font-weight: 750;
            letter-spacing: 1.5px;
        }

        .rocket-register .intro-label span {
            width: 7px;
            height: 7px;

            border-radius: 50%;

            background: #00e5ff;
            box-shadow: 0 0 12px #00e5ff;
        }

        .rocket-register .rocket-intro h1 {
            max-width: 620px;

            margin: 0 0 22px;

            font-size: clamp(42px, 5.5vw, 76px);
            line-height: 1.08;
            letter-spacing: -2.5px;

            animation: rocketIntroReveal .8s ease both;
        }

        .rocket-register .rocket-intro h1 span {
            display: block;
            margin-top: 5px;

            background: linear-gradient(
                90deg,
                #00e5ff,
                #578bff,
                #c06aff
            );

            -webkit-background-clip: text;
            background-clip: text;

            color: transparent;
        }

        .rocket-register .intro-description {
            max-width: 470px;

            color: var(--rocket-muted);

            font-size: 17px;
            line-height: 1.8;

            animation: rocketIntroReveal 1s ease both;
        }

        @keyframes rocketIntroReveal {
            from {
                opacity: 0;
                transform: translateY(22px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Rocket illustration */

        .rocket-register .rocket-scene {
            position: relative;

            width: min(100%, 490px);
            height: 290px;

            margin: 10px auto 15px;

            display: grid;
            place-items: center;

            perspective: 800px;
        }

        .rocket-register .orbit {
            position: absolute;

            width: 290px;
            height: 100px;

            border: 1px solid rgba(80, 139, 255, .48);
            border-radius: 50%;

            transform: rotate(-28deg);

            animation: rocketOrbitGlow 4s ease-in-out infinite alternate;
        }

        .rocket-register .orbit-two {
            width: 340px;
            height: 125px;

            transform: rotate(25deg);

            border-color: rgba(169, 90, 255, .3);
        }

        @keyframes rocketOrbitGlow {
            from {
                opacity: .35;
            }

            to {
                opacity: 1;
            }
        }

        .rocket-register .rocket-emoji {
            position: relative;
            z-index: 3;

            font-size: 125px;
            line-height: 1;

            filter: drop-shadow(0 0 22px rgba(0, 198, 255, .35));

            transform: rotate(-42deg);

            animation: rocketFloat 2.7s ease-in-out infinite;
        }

        @keyframes rocketFloat {
            0%, 100% {
                transform: translateY(8px) rotate(-42deg);
            }

            50% {
                transform: translateY(-14px) rotate(-39deg);
            }
        }

        /* Rocket flame */

        .rocket-register .rocket-flame {
            position: absolute;
            z-index: 2;

            left: calc(50% - 12px);
            top: 58%;

            width: 25px;
            height: 80px;

            border-radius: 50% 50% 60% 60%;

            background: linear-gradient(
                to bottom,
                #fff9bd,
                #ffad47 40%,
                #ff55da 80%,
                transparent
            );

            filter: blur(4px);

            transform: rotate(42deg);
            transform-origin: top center;

            animation: rocketFlameFlicker .16s infinite alternate;
        }

        @keyframes rocketFlameFlicker {
            from {
                opacity: .65;
                height: 55px;
                filter: blur(3px);
            }

            to {
                opacity: 1;
                height: 85px;
                filter: blur(6px);
            }
        }

        /* Rocket smoke */

        .rocket-register .smoke {
            position: absolute;
            bottom: 12px;

            width: 90px;
            height: 60px;

            border-radius: 50%;

            background: rgba(102, 112, 255, .22);

            filter: blur(25px);

            animation: rocketSmokePulse 3s ease-in-out infinite alternate;
        }

        .rocket-register .smoke-two {
            left: 20%;
            bottom: 20px;

            background: rgba(0, 205, 255, .2);

            animation-delay: -.8s;
        }

        .rocket-register .smoke-three {
            right: 20%;
            bottom: 35px;

            background: rgba(186, 69, 255, .25);

            animation-delay: -1.5s;
        }

        @keyframes rocketSmokePulse {
            from {
                transform: scale(.8) translateY(5px);
            }

            to {
                transform: scale(1.3) translateY(-8px);
            }
        }

        /* Benefits */

        .rocket-register .rocket-benefits {
            display: grid;
            gap: 16px;

            margin-top: 20px;
        }

        .rocket-register .benefit {
            display: flex;
            align-items: center;

            gap: 14px;

            color: #e5ebff;
            font-size: 14px;
        }

        .rocket-register .benefit-icon {
            width: 43px;
            height: 43px;

            flex: 0 0 43px;

            display: grid;
            place-items: center;

            border-radius: 14px;

            background: linear-gradient(
                135deg,
                rgba(0, 217, 255, .22),
                rgba(139, 65, 255, .3)
            );

            border: 1px solid rgba(113, 147, 255, .25);

            font-size: 20px;
        }

        /* Registration card */

        .rocket-register .register-card {
            position: relative;

            width: 100%;
            min-width: 0;

            padding: clamp(25px, 3vw, 44px);

            border: 1px solid rgba(112, 141, 255, .45);
            border-radius: 25px;

            background: linear-gradient(
                145deg,
                rgba(20, 39, 96, .76),
                rgba(9, 17, 57, .84)
            );

            box-shadow:
                0 25px 80px rgba(0, 0, 0, .28),
                inset 0 1px rgba(255, 255, 255, .08);

            -webkit-backdrop-filter: blur(22px);
            backdrop-filter: blur(22px);

            animation: rocketCardReveal .8s ease both;
        }

        @keyframes rocketCardReveal {
            from {
                opacity: 0;
                transform: translateY(25px) scale(.98);
            }

            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .rocket-register .register-heading {
            margin: 0 0 9px;

            font-size: clamp(27px, 3vw, 34px);
            font-weight: 750;
            letter-spacing: -.7px;
        }

        .rocket-register .register-heading span {
            color: var(--rocket-cyan);
        }

        .rocket-register .register-subtitle {
            margin: 0 0 26px;

            color: var(--rocket-muted);

            font-size: 14px;
            line-height: 1.7;
        }

        /* Success and error messages */

        .rocket-register .register-message {
            padding: 12px 14px;
            margin-bottom: 18px;

            border-radius: 10px;

            font-size: 13px;
            line-height: 1.5;

            overflow-wrap: anywhere;
        }

        .rocket-register .register-error {
            color: #ffd2d9;

            background: rgba(255, 62, 99, .12);
            border: 1px solid rgba(255, 62, 99, .35);
        }

        .rocket-register .register-success {
            color: #baffeb;

            background: rgba(0, 225, 164, .1);
            border: 1px solid rgba(0, 225, 164, .3);
        }

        /* Form */

        .rocket-register .register-form {
            display: grid;
            gap: 16px;
        }

        .rocket-register .field-group {
            position: relative;
            min-width: 0;
        }

        .rocket-register .field-group label {
            display: block;

            margin-bottom: 7px;

            color: #cbd7f7;

            font-size: 12px;
            font-weight: 650;
        }

        .rocket-register .field-group input,
        .rocket-register .field-group select {
            display: block;

            width: 100%;
            min-width: 0;
            min-height: 52px;

            padding: 14px 15px;

            border: 1px solid rgba(111, 143, 231, .48);
            border-radius: 12px;

            outline: none;

            background: rgba(22, 43, 104, .6);
            color: #fff;

            font-family: inherit;
            font-size: 14px;

            transition:
                border-color .25s,
                box-shadow .25s,
                background .25s,
                transform .25s;
        }

        .rocket-register .field-group input::placeholder {
            color: #91a6dc;
        }

        .rocket-register .field-group select {
            cursor: pointer;
        }

        .rocket-register .field-group select option {
            background: #111b48;
            color: white;
        }

        .rocket-register .field-group input:focus,
        .rocket-register .field-group select:focus {
            border-color: var(--rocket-cyan);

            background: rgba(23, 48, 117, .9);

            box-shadow: 0 0 0 3px rgba(0, 217, 255, .12);

            transform: translateY(-1px);
        }

        /* Submit button */

        .rocket-register .register-button {
            width: 100%;
            min-height: 56px;

            margin-top: 6px;
            padding: 15px 20px;

            border: 0;
            border-radius: 30px;

            background: linear-gradient(
                100deg,
                #00cfe8,
                #3284ff,
                #a345f5
            );

            background-size: 200% auto;

            color: white;

            font-size: 16px;
            font-weight: 750;

            cursor: pointer;

            box-shadow: 0 9px 28px rgba(73, 98, 255, .25);

            transition:
                background-position .4s,
                transform .3s,
                box-shadow .3s;
        }

        .rocket-register .register-button:hover {
            background-position: right center;

            transform: translateY(-3px);

            box-shadow: 0 13px 32px rgba(73, 98, 255, .4);
        }

        .rocket-register .register-button:active {
            transform: translateY(0) scale(.99);
        }

        .rocket-register .register-button:focus-visible,
        .rocket-register a:focus-visible {
            outline: 2px solid var(--rocket-cyan);
            outline-offset: 4px;
        }

        .rocket-register .login-prompt {
            margin: 22px 0 0;

            text-align: center;

            color: var(--rocket-muted);
            font-size: 13px;
            line-height: 1.7;
        }

        .rocket-register .login-prompt a {
            color: #47e3ff;

            text-decoration: none;
            font-weight: 700;
        }

        .rocket-register .login-prompt a:hover {
            text-decoration: underline;
        }

        .rocket-register .terms {
            margin-top: 18px;

            color: #8195c7;

            text-align: center;

            font-size: 11px;
            line-height: 1.7;
        }

        /* Tablet layout */

        @media (max-width: 950px) {
            .rocket-register .rocket-layout {
                grid-template-columns: minmax(0, 1fr);

                max-width: 560px;

                gap: 20px;
                margin-top: 35px;
            }

            .rocket-register .rocket-intro {
                text-align: center;
                padding: 10px 0;
            }

            .rocket-register .rocket-intro h1,
            .rocket-register .intro-description {
                margin-left: auto;
                margin-right: auto;
            }

            .rocket-register .rocket-scene {
                height: 230px;
                max-width: 390px;
            }

            .rocket-register .rocket-emoji {
                font-size: 100px;
            }

            .rocket-register .rocket-benefits {
                max-width: 330px;

                margin: 20px auto;

                text-align: left;
            }

            .rocket-register .register-card {
                width: 100%;
            }
        }

        /* Mobile layout */

        @media (max-width: 520px) {
            body.rocket-register {
                padding: 20px 16px 35px;
            }

            .rocket-register .rocket-header {
                gap: 10px;
            }

            .rocket-register .rocket-logo {
                font-size: 24px;
            }

            .rocket-register .header-login {
                gap: 8px;
                font-size: 11px;
            }

            .rocket-register .header-login a {
                padding: 9px 15px;
            }

            .rocket-register .rocket-layout {
                margin-top: 22px;
            }

            .rocket-register .rocket-intro h1 {
                font-size: 43px;
                letter-spacing: -1.5px;
            }

            .rocket-register .intro-description {
                font-size: 15px;
            }

            .rocket-register .rocket-scene {
                height: 185px;
            }

            .rocket-register .rocket-emoji {
                font-size: 85px;
            }

            .rocket-register .orbit {
                width: 240px;
                height: 85px;
            }

            .rocket-register .orbit-two {
                width: 275px;
                height: 105px;
            }

            .rocket-register .register-card {
                padding: 25px 20px;
                border-radius: 19px;
            }

            .rocket-register .register-heading {
                font-size: 27px;
            }

            .rocket-register .field-group input,
            .rocket-register .field-group select {
                font-size: 16px;
            }
        }

        /* Extra-small screens */

        @media (max-width: 360px) {
            body.rocket-register {
                padding-left: 12px;
                padding-right: 12px;
            }

            .rocket-register .rocket-logo {
                font-size: 21px;
            }

            .rocket-register .header-login {
                font-size: 10px;
            }

            .rocket-register .header-login a {
                padding: 8px 11px;
            }

            .rocket-register .rocket-intro h1 {
                font-size: 36px;
            }

            .rocket-register .register-card {
                padding: 22px 15px;
            }
        }

        /* Respect reduced-motion preferences */

        @media (prefers-reduced-motion: reduce) {
            .rocket-register *,
            .rocket-register *::before,
            .rocket-register *::after {
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                scroll-behavior: auto !important;
                transition-duration: .01ms !important;
            }
        }
    </style>
</head>

<body class="rocket-register">

    <!-- Background glows -->
    <div class="space-glow glow-left" aria-hidden="true"></div>
    <div class="space-glow glow-right" aria-hidden="true"></div>

    <!-- Animated stars -->
    <div class="stars" aria-hidden="true">
        <span class="star"></span>
        <span class="star"></span>
        <span class="star"></span>
        <span class="star"></span>
        <span class="star"></span>
        <span class="star"></span>
        <span class="star"></span>
        <span class="star"></span>
    </div>

    <!-- Header -->
    <header class="rocket-header">

        <a href="index.php" class="rocket-logo">
            Talent<span>Sprint</span>
        </a>

        <div class="header-login">
            <span>Already have an account?</span>
            <a href="login.php">Login</a>
        </div>

    </header>

    <!-- Main content -->
    <main class="rocket-layout">

        <!-- Introduction section -->
        <section class="rocket-intro">

            <div class="intro-label">
                <span></span>
                YOUR NEXT CHAPTER STARTS HERE
            </div>

            <h1>
                Your Career
                <span>Starts Here.</span>
            </h1>

            <p class="intro-description">
                Join TalentSprint and take off towards your dream career.
                Discover internships, develop in-demand skills, and unlock
                opportunities that help you grow.
            </p>

            <!-- Animated rocket illustration -->
            <div class="rocket-scene" aria-label="Animated rocket illustration">

                <div class="orbit"></div>
                <div class="orbit orbit-two"></div>

                <div class="smoke"></div>
                <div class="smoke smoke-two"></div>
                <div class="smoke smoke-three"></div>

                <div class="rocket-flame"></div>

                <div class="rocket-emoji" aria-hidden="true">
                    🚀
                </div>

            </div>

            <!-- Benefits -->
            <div class="rocket-benefits">

                <div class="benefit">
                    <div class="benefit-icon" aria-hidden="true">🚀</div>
                    <span>Discover exciting internships</span>
                </div>

                <div class="benefit">
                    <div class="benefit-icon" aria-hidden="true">📚</div>
                    <span>Learn industry-ready skills</span>
                </div>

                <div class="benefit">
                    <div class="benefit-icon" aria-hidden="true">💼</div>
                    <span>Build your professional future</span>
                </div>

            </div>

        </section>

        <!-- Registration form -->
        <section class="register-card" aria-labelledby="register-title">

            <h2 class="register-heading" id="register-title">
                Create Your <span>Account</span>
            </h2>

            <p class="register-subtitle">
                Take the first step towards a brighter future.
            </p>

            <!-- PHP error message -->
            <?php if ($error !== ''): ?>
                <div class="register-message register-error" role="alert">
                    <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
                </div>
            <?php endif; ?>

            <!-- PHP success message -->
            <?php if ($success !== ''): ?>
                <div class="register-message register-success" role="status">
                    <?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>

                    <div style="margin-top: 10px;">
                        <a
                            href="login.php"
                            style="color: #baffeb; font-weight: 700;"
                        >
                            Continue to sign in →
                        </a>
                    </div>
                </div>
            <?php endif; ?>

            <form
                class="register-form"
                action="register.php"
                method="POST"
            >

                <!-- Full name -->
                <div class="field-group">
                    <label for="name">Full Name</label>

                    <input
                        type="text"
                        id="name"
                        name="name"
                        placeholder="Enter your full name"
                        value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>"
                        autocomplete="name"
                        maxlength="100"
                        required
                    >
                </div>

                <!-- Email -->
                <div class="field-group">
                    <label for="email">Email Address</label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Enter your email address"
                        value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
                        autocomplete="email"
                        maxlength="254"
                        required
                    >
                </div>

                <!-- Password -->
                <div class="field-group">
                    <label for="password">Password</label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Create a password (minimum 6 characters)"
                        autocomplete="new-password"
                        minlength="6"
                        required
                    >
                </div>

                <!-- Account type -->
                <div class="field-group">
                    <label for="role">Account Type</label>

                    <select id="role" name="role" required>

                        <option
                            value="student"
                            <?= $role === 'student' ? 'selected' : '' ?>
                        >
                            Student
                        </option>

                        <option
                            value="company"
                            <?= $role === 'company' ? 'selected' : '' ?>
                        >
                            Company
                        </option>

                    </select>
                </div>

                <!-- Submit -->
                <button type="submit" class="register-button">
                    Create Account &nbsp; →
                </button>

            </form>

            <p class="login-prompt">
                Already registered?
                <a href="login.php">Sign in here</a>
            </p>

            <p class="terms">
                By creating an account, you agree to use TalentSprint
                responsibly and provide accurate information.
            </p>

        </section>

    </main>

</body>
</html>