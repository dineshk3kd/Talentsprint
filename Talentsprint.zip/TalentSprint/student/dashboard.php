<?php
session_start();

require_once __DIR__ . '/../config/database.php';

require_role('student');

$data = db_load();

$student = db_student_by_user(
    $data,
    (int) $_SESSION['user_id']
);

$sid = (int) ($student['id'] ?? 0);

$apps = array_values(array_filter(
    $data['applications'],
    fn($a) => (int) $a['student_id'] === $sid
));

$short = count(array_filter(
    $apps,
    fn($a) => ($a['status'] ?? '') === 'Shortlisted'
));

$open = count(array_filter(
    $data['internships'],
    fn($i) => ($i['status'] ?? 'Open') === 'Open'
));

$flash = take_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Student Dashboard | TalentSprint</title>

    <link rel="stylesheet" href="../css/style.css?v=4">

    <style>
        /* ==========================================
           TALENTSPRINT COSMIC MULTICOLOR DASHBOARD
           Dashboard-only styling
        ========================================== */

        body:has(main.dashboard) {
            --ts-bg: #07091b;
            --ts-panel: #12173b;
            --ts-cyan: #00e5ff;
            --ts-teal: #00f5c4;
            --ts-blue: #477bff;
            --ts-purple: #a855f7;
            --ts-pink: #ff45d4;
            --ts-orange: #ffae57;
            --ts-text: #f8faff;
            --ts-muted: #b4bfdc;

            position: relative;
            min-height: 100vh;
            overflow-x: hidden;
            color: var(--ts-text);
            background:
                radial-gradient(
                    circle at 5% 5%,
                    rgba(0,229,255,.12),
                    transparent 28%
                ),
                radial-gradient(
                    circle at 90% 10%,
                    rgba(168,85,247,.16),
                    transparent 30%
                ),
                radial-gradient(
                    circle at 50% 90%,
                    rgba(255,69,212,.08),
                    transparent 35%
                ),
                var(--ts-bg);
            font-family: Inter, "Segoe UI", Arial, sans-serif;
        }

        body:has(main.dashboard) * {
            box-sizing: border-box;
        }

        body:has(main.dashboard) main.dashboard {
            position: relative;
            z-index: 1;
            width: min(1250px, 100%);
            margin: 0 auto;
            padding: 38px 25px 65px;
        }

        body:has(main.dashboard) a {
            text-decoration: none;
        }

        /* ==========================================
           SHOOTING STARS BACKGROUND
        ========================================== */

        .ts-starfield {
            position: fixed;
            inset: 0;
            z-index: 0;
            overflow: hidden;
            pointer-events: none;
        }

        .ts-star {
            position: absolute;
            top: -100px;
            left: var(--star-left);
            width: 2px;
            height: var(--star-length);
            opacity: 0;
            border-radius: 999px;
            background: linear-gradient(
                to bottom,
                rgba(255,255,255,0),
                var(--star-color)
            );
            box-shadow: 0 0 8px var(--star-color);
            transform: rotate(42deg);
            transform-origin: top center;
            animation: tsShootingStar var(--star-duration) linear infinite;
            animation-delay: var(--star-delay);
        }

        @keyframes tsShootingStar {
            0% {
                opacity: 0;
                transform: translate3d(0, 0, 0) rotate(42deg);
            }

            5% {
                opacity: .9;
            }

            18% {
                opacity: .75;
            }

            32% {
                opacity: 0;
                transform:
                    translate3d(-350px, 750px, 0)
                    rotate(42deg);
            }

            100% {
                opacity: 0;
                transform:
                    translate3d(-350px, 750px, 0)
                    rotate(42deg);
            }
        }

        .ts-twinkle {
            position: absolute;
            width: 3px;
            height: 3px;
            border-radius: 50%;
            background: #fff;
            box-shadow:
                0 0 7px #fff,
                0 0 14px var(--twinkle-color);
            animation: tsTwinkle 2.5s ease-in-out infinite alternate;
            animation-delay: var(--twinkle-delay);
        }

        @keyframes tsTwinkle {
            from {
                opacity: .2;
                transform: scale(.7);
            }

            to {
                opacity: 1;
                transform: scale(1.7);
            }
        }

        /* ==========================================
           WELCOME SECTION
        ========================================== */

        body:has(main.dashboard) .page-heading {
            position: relative;
            isolation: isolate;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 30px;
            margin: 0 0 28px;
            padding: 40px;
            border: 1px solid rgba(0,229,255,.3);
            border-radius: 28px;
            background:
                radial-gradient(
                    circle at 90% 10%,
                    rgba(255,69,212,.17),
                    transparent 30%
                ),
                linear-gradient(
                    120deg,
                    rgba(13,24,65,.98),
                    rgba(20,15,58,.96),
                    rgba(9,36,66,.97)
                );
            box-shadow:
                0 20px 55px rgba(0,0,0,.24),
                inset 0 1px 0 rgba(255,255,255,.06);
        }

        body:has(main.dashboard) .page-heading::before {
            content: "";
            position: absolute;
            z-index: -1;
            width: 280px;
            height: 280px;
            right: 12%;
            top: -180px;
            border-radius: 50%;
            background: rgba(0,229,255,.15);
            filter: blur(35px);
        }

        body:has(main.dashboard) .page-heading::after {
            content: "✦";
            position: absolute;
            z-index: -1;
            right: 34%;
            bottom: 5px;
            color: rgba(0,229,255,.15);
            font-size: 150px;
            line-height: 1;
        }

        body:has(main.dashboard) .page-heading h1 {
            margin: 0 0 14px;
            font-size: clamp(32px, 4vw, 49px);
            font-weight: 950;
            letter-spacing: -1.8px;
            line-height: 1.15;
            color: #fff;
        }

        body:has(main.dashboard) .page-heading h1 span {
            background: linear-gradient(
                90deg,
                var(--ts-teal),
                var(--ts-cyan),
                #a78bfa,
                var(--ts-pink),
                var(--ts-orange)
            );
            background-size: 200% auto;
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: tsTextGradient 6s ease-in-out infinite alternate;
        }

        @keyframes tsTextGradient {
            from { background-position: 0% center; }
            to { background-position: 100% center; }
        }

        body:has(main.dashboard) .page-heading p {
            max-width: 580px;
            margin: 0;
            color: var(--ts-muted);
            font-size: 15px;
            line-height: 1.9;
        }

        body:has(main.dashboard) .page-heading .btn {
            flex-shrink: 0;
        }

        /* ==========================================
           BUTTONS
        ========================================== */

        body:has(main.dashboard) .btn,
        body:has(main.dashboard) a.btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            padding: 14px 23px;
            border: 0;
            border-radius: 30px;
            color: #fff;
            background: linear-gradient(
                110deg,
                #06b6d4,
                #477bff,
                #a855f7,
                #ec4899
            );
            background-size: 220% auto;
            font-size: 14px;
            font-weight: 850;
            box-shadow: 0 8px 26px rgba(79,125,255,.23);
            transition:
                transform .25s ease,
                box-shadow .25s ease,
                background-position .4s ease;
        }

        body:has(main.dashboard) .btn:hover,
        body:has(main.dashboard) a.btn:hover {
            transform: translateY(-3px);
            background-position: 100% center;
            box-shadow: 0 12px 30px rgba(168,85,247,.32);
        }

        /* ==========================================
           FLASH MESSAGE
        ========================================== */

        body:has(main.dashboard) .flash {
            margin: 0 0 28px;
            padding: 16px 20px;
            border: 1px solid rgba(0,245,196,.35);
            border-left: 4px solid var(--ts-teal);
            border-radius: 14px;
            color: #c9fff1;
            background: linear-gradient(
                110deg,
                rgba(0,245,196,.1),
                rgba(0,229,255,.06),
                rgba(71,123,255,.08)
            );
            box-shadow: 0 8px 25px rgba(0,0,0,.12);
        }

        /* ==========================================
           STATISTIC CARDS
        ========================================== */

        body:has(main.dashboard) .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 22px;
            margin: 28px 0 40px;
        }

        body:has(main.dashboard) .stat-card {
            position: relative;
            isolation: isolate;
            overflow: hidden;
            min-width: 0;
            padding: 27px;
            border: 1px solid rgba(255,255,255,.15);
            border-radius: 23px;
            color: #fff;
            box-shadow: 0 14px 35px rgba(0,0,0,.2);
            transition:
                transform .3s ease,
                box-shadow .3s ease,
                filter .3s ease;
        }

        body:has(main.dashboard) .stat-card:nth-child(1) {
            background: linear-gradient(
                135deg,
                #6d28d9,
                #9333ea,
                #db2777
            );
        }

        body:has(main.dashboard) .stat-card:nth-child(2) {
            background: linear-gradient(
                135deg,
                #be185d,
                #f43f5e,
                #f97316
            );
        }

        body:has(main.dashboard) .stat-card:nth-child(3) {
            background: linear-gradient(
                135deg,
                #1d4ed8,
                #0891b2,
                #0d9488
            );
        }

        body:has(main.dashboard) .stat-card::before {
            content: "";
            position: absolute;
            z-index: -1;
            top: -60px;
            right: -45px;
            width: 170px;
            height: 170px;
            border-radius: 50%;
            background: rgba(255,255,255,.13);
            transition: transform .35s ease;
        }

        body:has(main.dashboard) .stat-card::after {
            content: "";
            position: absolute;
            z-index: -1;
            right: -25px;
            bottom: -95px;
            width: 220px;
            height: 170px;
            border: 1px solid rgba(255,255,255,.18);
            border-radius: 50%;
            box-shadow:
                0 -12px 0 rgba(255,255,255,.035),
                0 -24px 0 rgba(255,255,255,.025);
        }

        body:has(main.dashboard) .stat-card:hover {
            transform: translateY(-8px);
            filter: saturate(1.15);
            box-shadow: 0 24px 45px rgba(0,0,0,.3);
        }

        body:has(main.dashboard) .stat-card:hover::before {
            transform: scale(1.35);
        }

        body:has(main.dashboard) .stat-card h3 {
            position: relative;
            z-index: 1;
            margin: 0 0 15px;
            color: rgba(255,255,255,.95);
            font-size: 15px;
            font-weight: 750;
        }

        body:has(main.dashboard) .stat-card .stat-number {
            position: relative;
            z-index: 1;
            display: block;
            color: #fff;
            font-size: clamp(34px,4vw,46px);
            font-weight: 950;
            line-height: 1.1;
        }

        body:has(main.dashboard) .stat-card p {
            position: relative;
            z-index: 1;
            margin: 12px 0 0;
            color: rgba(255,255,255,.88);
            font-size: 13px;
            line-height: 1.6;
        }

        /* ==========================================
           SECTION HEADINGS
        ========================================== */

        body:has(main.dashboard) .dashboard-section {
            margin-top: 34px;
            padding: 29px;
            border: 1px solid rgba(255,255,255,.09);
            border-radius: 24px;
            background: linear-gradient(
                140deg,
                rgba(18,23,59,.92),
                rgba(12,16,43,.91)
            );
            box-shadow: 0 16px 42px rgba(0,0,0,.17);
        }

        body:has(main.dashboard) .dashboard-section h2 {
            margin: 0 0 23px;
            color: #fff;
            font-size: 25px;
            font-weight: 900;
            letter-spacing: -.6px;
        }

        body:has(main.dashboard) .dashboard-section h2 span {
            background: linear-gradient(
                90deg,
                var(--ts-cyan),
                #a78bfa,
                var(--ts-pink)
            );
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* ==========================================
           QUICK ACTION CARDS
        ========================================== */

        body:has(main.dashboard) .quick-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 19px;
        }

        body:has(main.dashboard) .quick-card {
            position: relative;
            isolation: isolate;
            overflow: hidden;
            display: block;
            min-width: 0;
            padding: 25px;
            border: 1px solid var(--card-accent);
            border-radius: 20px;
            background: linear-gradient(
                145deg,
                var(--card-bg),
                rgba(13,17,47,.95)
            );
            transition:
                transform .28s ease,
                border-color .28s ease,
                box-shadow .28s ease,
                background .28s ease;
        }

        body:has(main.dashboard) .quick-card:nth-child(1) {
            --card-accent: rgba(168,85,247,.55);
            --card-bg: rgba(126,34,206,.13);
            --card-glow: #a855f7;
        }

        body:has(main.dashboard) .quick-card:nth-child(2) {
            --card-accent: rgba(0,229,255,.45);
            --card-bg: rgba(8,145,178,.12);
            --card-glow: #00e5ff;
        }

        body:has(main.dashboard) .quick-card:nth-child(3) {
            --card-accent: rgba(0,245,196,.42);
            --card-bg: rgba(5,150,105,.12);
            --card-glow: #00f5c4;
        }

        body:has(main.dashboard) .quick-card::after {
            content: "↗";
            position: absolute;
            z-index: -1;
            right: 15px;
            bottom: -38px;
            color: var(--card-glow);
            opacity: .1;
            font-size: 120px;
            font-weight: 900;
            transition: transform .3s ease, opacity .3s ease;
        }

        body:has(main.dashboard) .quick-card:hover {
            transform: translateY(-7px);
            border-color: var(--card-glow);
            background: linear-gradient(
                145deg,
                var(--card-bg),
                rgba(26,31,74,.98)
            );
            box-shadow: 0 18px 38px rgba(0,0,0,.24);
        }

        body:has(main.dashboard) .quick-card:hover::after {
            opacity: .2;
            transform: translate(-5px,-8px);
        }

        body:has(main.dashboard) .quick-card h3 {
            position: relative;
            margin: 0 0 11px;
            color: var(--card-glow);
            font-size: 18px;
            font-weight: 850;
        }

        body:has(main.dashboard) .quick-card p {
            position: relative;
            margin: 0;
            color: var(--ts-muted);
            font-size: 14px;
            line-height: 1.8;
        }

        body:has(main.dashboard) .quick-card .quick-arrow {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 42px;
            height: 42px;
            margin-top: 20px;
            border-radius: 13px;
            color: #080b20;
            background: var(--card-glow);
            font-size: 21px;
            font-weight: 900;
            transition: transform .25s ease;
        }

        body:has(main.dashboard) .quick-card:hover .quick-arrow {
            transform: translateX(5px);
        }

        /* ==========================================
           CAREER PROMOTION CARD
        ========================================== */

        body:has(main.dashboard) .career-card {
            position: relative;
            isolation: isolate;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;
            margin-top: 30px;
            padding: 34px;
            border: 1px solid rgba(255,255,255,.18);
            border-radius: 25px;
            color: #fff;
            background: linear-gradient(
                110deg,
                #6d28d9,
                #4338ca,
                #0369a1,
                #0d9488,
                #a16207
            );
            background-size: 220% 220%;
            animation: tsCareerGradient 12s ease infinite;
            box-shadow: 0 18px 42px rgba(0,0,0,.22);
        }

        @keyframes tsCareerGradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        body:has(main.dashboard) .career-card::before {
            content: "✦";
            position: absolute;
            z-index: -1;
            right: 24%;
            top: -65px;
            color: rgba(255,255,255,.12);
            font-size: 180px;
        }

        body:has(main.dashboard) .career-card h2,
        body:has(main.dashboard) .career-card h3 {
            margin: 0 0 12px;
            color: #fff;
            font-size: clamp(22px,3vw,30px);
            font-weight: 900;
        }

        body:has(main.dashboard) .career-card p {
            max-width: 690px;
            margin: 0;
            color: rgba(255,255,255,.9);
            font-size: 14px;
            line-height: 1.9;
        }

        body:has(main.dashboard) .career-card a {
            position: relative;
            flex-shrink: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            padding: 14px 22px;
            border-radius: 30px;
            color: #4338ca;
            background: #fff;
            font-size: 13px;
            font-weight: 900;
            transition:
                transform .25s ease,
                background .25s ease,
                color .25s ease;
        }

        body:has(main.dashboard) .career-card a:hover {
            transform: translateY(-3px);
            color: #fff;
            background: #f97316;
        }

        /* ==========================================
           ACCESSIBILITY
        ========================================== */

        body:has(main.dashboard) a:focus-visible,
        body:has(main.dashboard) button:focus-visible {
            outline: 3px solid var(--ts-orange);
            outline-offset: 4px;
        }

        /* ==========================================
           RESPONSIVE
        ========================================== */

        @media (max-width: 900px) {
            body:has(main.dashboard) .page-heading {
                padding: 30px;
            }

            body:has(main.dashboard) .stats-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            body:has(main.dashboard) .quick-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            body:has(main.dashboard) .career-card {
                align-items: flex-start;
                flex-direction: column;
            }
        }

        @media (max-width: 600px) {
            body:has(main.dashboard) main.dashboard {
                padding: 24px 15px 45px;
            }

            body:has(main.dashboard) .page-heading {
                align-items: flex-start;
                flex-direction: column;
                gap: 20px;
                padding: 26px 21px;
            }

            body:has(main.dashboard) .page-heading h1 {
                font-size: 34px;
            }

            body:has(main.dashboard) .stats-grid,
            body:has(main.dashboard) .quick-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            body:has(main.dashboard) .stat-card {
                padding: 23px;
            }

            body:has(main.dashboard) .dashboard-section {
                padding: 21px 17px;
            }

            body:has(main.dashboard) .dashboard-section h2 {
                font-size: 22px;
            }

            body:has(main.dashboard) .quick-card {
                padding: 22px;
            }

            body:has(main.dashboard) .career-card {
                padding: 26px 21px;
            }

            .ts-star {
                animation-duration: calc(var(--star-duration) * 1.5);
            }
        }

        @media (prefers-reduced-motion: reduce) {
            body:has(main.dashboard) *,
            body:has(main.dashboard) *::before,
            body:has(main.dashboard) *::after {
                animation: none !important;
                scroll-behavior: auto !important;
                transition: none !important;
            }
        }
    </style>
</head>

<body>

<!-- Animated background stars -->
<div class="ts-starfield" aria-hidden="true">
    <span class="ts-star" style="--star-left: 12%; --star-length: 120px; --star-duration: 6s; --star-delay: 0s; --star-color: #00e5ff;"></span>
    <span class="ts-star" style="--star-left: 32%; --star-length: 95px; --star-duration: 8s; --star-delay: 2s; --star-color: #a855f7;"></span>
    <span class="ts-star" style="--star-left: 58%; --star-length: 135px; --star-duration: 7s; --star-delay: 4s; --star-color: #ff45d4;"></span>
    <span class="ts-star" style="--star-left: 78%; --star-length: 110px; --star-duration: 9s; --star-delay: 1s; --star-color: #00f5c4;"></span>
    <span class="ts-star" style="--star-left: 92%; --star-length: 125px; --star-duration: 7s; --star-delay: 5s; --star-color: #ffae57;"></span>

    <span class="ts-twinkle" style="top: 15%; left: 12%; --twinkle-color: #00e5ff; --twinkle-delay: .3s;"></span>
    <span class="ts-twinkle" style="top: 24%; left: 83%; --twinkle-color: #ff45d4; --twinkle-delay: 1s;"></span>
    <span class="ts-twinkle" style="top: 52%; left: 8%; --twinkle-color: #a855f7; --twinkle-delay: .7s;"></span>
    <span class="ts-twinkle" style="top: 67%; left: 71%; --twinkle-color: #00f5c4; --twinkle-delay: 1.5s;"></span>
    <span class="ts-twinkle" style="top: 83%; left: 43%; --twinkle-color: #ffae57; --twinkle-delay: .5s;"></span>
    <span class="ts-twinkle" style="top: 38%; left: 56%; --twinkle-color: #00e5ff; --twinkle-delay: 1.8s;"></span>
</div>

<?php include __DIR__ . '/student_nav.php'; ?>

<main class="dashboard">

    <!-- WELCOME -->
    <section class="page-heading">
        <div>
            <h1>
                Hi, <span><?= e($_SESSION['name'] ?? 'Student') ?>!</span>
            </h1>

            <p>
                Welcome to your TalentSprint dashboard. Track your applications,
                discover exciting internships, and take the next step toward
                your dream career.
            </p>
        </div>

        <a class="btn" href="internships.php">
            Explore Internships <span aria-hidden="true">→</span>
        </a>
    </section>

    <!-- FLASH MESSAGE -->
    <?php if (!empty($flash)): ?>
        <div class="flash">
            <?= e($flash) ?>
        </div>
    <?php endif; ?>

    <!-- STATISTICS -->
    <section class="stats-grid" aria-label="Your internship statistics">

        <article class="stat-card">
            <h3>Applications Submitted</h3>

            <span class="stat-number">
                <?= count($apps) ?>
            </span>

            <p>↗ Keep moving toward your goals!</p>
        </article>

        <article class="stat-card">
            <h3>Shortlisted Applications</h3>

            <span class="stat-number">
                <?= $short ?>
            </span>

            <p>✦ Great progress! Keep it up.</p>
        </article>

        <article class="stat-card">
            <h3>Open Opportunities</h3>

            <span class="stat-number">
                <?= $open ?>
            </span>

            <p>✧ New opportunities are waiting.</p>
        </article>

    </section>

    <!-- QUICK ACTIONS -->
    <section class="dashboard-section">

        <h2><span>✦</span> Quick Actions</h2>

        <div class="quick-grid">

            <a class="quick-card" href="profile.php">
                <h3>Complete Your Profile</h3>

                <p>
                    Update your personal details, education, skills, and resume
                    so employers can learn more about you.
                </p>

                <span class="quick-arrow" aria-hidden="true">→</span>
            </a>

            <a class="quick-card" href="internships.php">
                <h3>Find an Internship</h3>

                <p>
                    Explore available opportunities and find roles that match
                    your interests and career goals.
                </p>

                <span class="quick-arrow" aria-hidden="true">→</span>
            </a>

            <a class="quick-card" href="applications.php">
                <h3>Track Your Applications</h3>

                <p>
                    Review your submitted applications and keep track of their
                    latest status.
                </p>

                <span class="quick-arrow" aria-hidden="true">→</span>
            </a>

        </div>

    </section>

    <!-- CAREER CALL TO ACTION -->
    <section class="career-card">

        <div>
            <h2>✦ Your next opportunity starts here</h2>

            <p>
                Every great career starts with a first step. Discover internships,
                strengthen your skills, and move closer to your professional goals
                with TalentSprint.
            </p>
        </div>

        <a href="internships.php">
            Discover Opportunities <span aria-hidden="true">→</span>
        </a>

    </section>

</main>

</body>
</html>