<?php
session_start();

require_once __DIR__ . '/../config/database.php';

require_role('student');

$data = db_load();

$uid = (int) $_SESSION['user_id'];
$user = db_user($data, $uid);
$student = db_student_by_user($data, $uid);

$message = '';
$messageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim($_POST['phone'] ?? '');
    $college = trim($_POST['college'] ?? '');
    $course = trim($_POST['course'] ?? '');
    $skills = trim($_POST['skills'] ?? '');
    $bio = trim($_POST['bio'] ?? '');

    $resume = $student['resume'] ?? '';

    if (
        isset($_FILES['resume']) &&
        $_FILES['resume']['error'] !== UPLOAD_ERR_NO_FILE
    ) {
        if ($_FILES['resume']['error'] !== UPLOAD_ERR_OK) {
            $message = 'Resume upload failed.';
            $messageType = 'error';

        } elseif (
            strtolower(
                pathinfo($_FILES['resume']['name'], PATHINFO_EXTENSION)
            ) !== 'pdf'
        ) {
            $message = 'Resume must be a PDF file.';
            $messageType = 'error';

        } elseif ($_FILES['resume']['size'] > 5 * 1024 * 1024) {
            $message = 'Resume must be smaller than 5 MB.';
            $messageType = 'error';

        } else {
            $dir = __DIR__ . '/../uploads';

            if (!is_dir($dir)) {
                @mkdir($dir, 0775, true);
            }

            $file = 'resume_' . $uid . '_' . time() . '.pdf';

            if (
                move_uploaded_file(
                    $_FILES['resume']['tmp_name'],
                    $dir . '/' . $file
                )
            ) {
                $resume = $file;
            } else {
                $message = 'Unable to save the resume.';
                $messageType = 'error';
            }
        }
    }

    if ($messageType === 'success') {
        $updated = false;

        foreach ($data['students'] as &$s) {
            if ((int) $s['user_id'] === $uid) {
                $s['phone'] = $phone;
                $s['college'] = $college;
                $s['course'] = $course;
                $s['skills'] = $skills;
                $s['bio'] = $bio;
                $s['resume'] = $resume;

                $updated = true;
                break;
            }
        }

        unset($s);

        if ($updated && db_save($data)) {
            $message = 'Profile updated successfully.';
            $student = db_student_by_user($data, $uid);
        } else {
            $message = 'Unable to update your profile.';
            $messageType = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Profile · TalentSprint</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>
        /* All visual changes are scoped to this profile page. */

        body:has(.ts-profile-page) {
            --dragon-bg: #07091b;
            --dragon-panel: rgba(15, 21, 53, .94);
            --dragon-cyan: #00e5ff;
            --dragon-teal: #00f5c4;
            --dragon-blue: #477bff;
            --dragon-purple: #a855f7;
            --dragon-pink: #ff45d4;
            --dragon-orange: #ffae57;
            --dragon-text: #f8faff;
            --dragon-muted: #b4bfdc;

            min-height: 100vh;
            color: var(--dragon-text);

            background:
                radial-gradient(
                    ellipse at 12% 10%,
                    rgba(71, 123, 255, .19),
                    transparent 35%
                ),
                radial-gradient(
                    ellipse at 88% 28%,
                    rgba(168, 85, 247, .16),
                    transparent 34%
                ),
                radial-gradient(
                    ellipse at 50% 100%,
                    rgba(0, 245, 196, .08),
                    transparent 40%
                ),
                var(--dragon-bg);

            overflow-x: hidden;
        }

        .ts-profile-page {
            position: relative;
            isolation: isolate;
            max-width: 1050px;
            margin: 0 auto;
            padding: 42px 25px 75px;
        }

        /* Animated star field */

        .ts-profile-space {
            position: fixed;
            inset: 0;
            z-index: -1;
            overflow: hidden;
            pointer-events: none;
        }

        .ts-profile-space .space-star {
            position: absolute;
            width: 3px;
            height: 3px;
            border-radius: 50%;
            background: #fff;
            box-shadow: 0 0 9px var(--dragon-cyan);

            animation: profile-twinkle 3s ease-in-out infinite alternate;
        }

        .ts-profile-space .space-star:nth-child(1) {
            top: 12%;
            left: 9%;
        }

        .ts-profile-space .space-star:nth-child(2) {
            top: 25%;
            left: 82%;
            animation-delay: .7s;
        }

        .ts-profile-space .space-star:nth-child(3) {
            top: 48%;
            left: 13%;
            animation-delay: 1.3s;
        }

        .ts-profile-space .space-star:nth-child(4) {
            top: 69%;
            left: 91%;
            animation-delay: 1.8s;
        }

        .ts-profile-space .space-star:nth-child(5) {
            top: 86%;
            left: 38%;
            animation-delay: 2.2s;
        }

        .ts-profile-space .space-star:nth-child(6) {
            top: 35%;
            left: 59%;
            animation-delay: .4s;
        }

        @keyframes profile-twinkle {
            from {
                opacity: .25;
                transform: scale(.7);
            }

            to {
                opacity: 1;
                transform: scale(1.5);
            }
        }

        /* Small flying dragon.
           The dragon is decorative and does not affect form controls. */

        .ts-flying-dragon {
            position: fixed;
            z-index: 0;
            top: 115px;
            left: -110px;

            width: 75px;
            height: 55px;

            pointer-events: none;
            opacity: .88;

            animation:
                dragon-flight 22s linear infinite,
                dragon-glow 3s ease-in-out infinite alternate;

            filter: drop-shadow(0 0 8px rgba(0, 229, 255, .35));
        }

        .ts-flying-dragon svg {
            display: block;
            width: 100%;
            height: 100%;
            overflow: visible;
        }

        .ts-dragon-wing {
            transform-box: fill-box;
            transform-origin: 50% 85%;
            animation: dragon-wing-flap .55s ease-in-out infinite alternate;
        }

        .ts-dragon-wing-back {
            transform-box: fill-box;
            transform-origin: 50% 90%;
            animation: dragon-wing-flap .55s ease-in-out infinite alternate-reverse;
        }

        .ts-dragon-tail {
            transform-box: fill-box;
            transform-origin: 100% 50%;
            animation: dragon-tail-sway 1.3s ease-in-out infinite alternate;
        }

        @keyframes dragon-flight {
            0% {
                left: -110px;
                top: 115px;
                transform: translateY(0) rotate(-5deg) scale(.8);
            }

            20% {
                top: 155px;
                transform: translateY(-10px) rotate(4deg) scale(.9);
            }

            45% {
                top: 95px;
                transform: translateY(8px) rotate(-3deg) scale(1);
            }

            70% {
                top: 145px;
                transform: translateY(-8px) rotate(5deg) scale(.9);
            }

            100% {
                left: calc(100% + 120px);
                top: 105px;
                transform: translateY(0) rotate(-3deg) scale(.8);
            }
        }

        @keyframes dragon-wing-flap {
            from {
                transform: rotate(-20deg) scaleY(.8);
            }

            to {
                transform: rotate(24deg) scaleY(1.05);
            }
        }

        @keyframes dragon-tail-sway {
            from {
                transform: rotate(-7deg);
            }

            to {
                transform: rotate(9deg);
            }
        }

        @keyframes dragon-glow {
            from {
                filter: drop-shadow(0 0 4px rgba(0, 229, 255, .25));
            }

            to {
                filter: drop-shadow(0 0 11px rgba(168, 85, 247, .55));
            }
        }

        /* Page heading */

        .ts-profile-page .page-heading {
            position: relative;
            z-index: 1;
            margin-bottom: 28px;
            animation: profile-enter .65s ease both;
        }

        .ts-profile-page .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 9px;

            padding: 9px 14px;
            margin: 0 0 17px;

            border: 1px solid rgba(0, 229, 255, .28);
            border-radius: 30px;

            background: rgba(0, 229, 255, .06);
            color: var(--dragon-cyan);

            font-size: 11px;
            font-weight: 850;
            letter-spacing: 2px;
        }

        .ts-profile-page .eyebrow::before {
            content: "";
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: var(--dragon-teal);
            box-shadow: 0 0 10px var(--dragon-teal);
        }

        .ts-profile-page .page-heading h1 {
            margin: 0 0 14px;

            font-size: clamp(35px, 5vw, 55px);
            line-height: 1.16;
            font-weight: 900;
            letter-spacing: -1px;

            background: linear-gradient(
                95deg,
                #ffffff,
                var(--dragon-cyan),
                var(--dragon-purple),
                var(--dragon-pink)
            );

            background-size: 220% auto;
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;

            animation: profile-gradient 8s linear infinite;
        }

        .ts-profile-page .page-heading p:not(.eyebrow) {
            max-width: 650px;
            margin: 0;

            color: var(--dragon-muted);
            font-size: 15px;
            line-height: 1.8;
        }

        @keyframes profile-gradient {
            to {
                background-position: 220% center;
            }
        }

        @keyframes profile-enter {
            from {
                opacity: 0;
                transform: translateY(15px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Feedback message */

        .ts-profile-page .alert {
            position: relative;
            z-index: 1;

            padding: 16px 19px;
            margin-bottom: 20px;

            border-radius: 13px;
            background: rgba(10, 18, 47, .94);

            color: var(--dragon-text);
            line-height: 1.7;

            animation: profile-enter .4s ease both;
        }

        .ts-profile-page .alert.success {
            border: 1px solid rgba(0, 245, 196, .4);
            box-shadow: inset 3px 0 0 var(--dragon-teal);
        }

        .ts-profile-page .alert.error {
            border: 1px solid rgba(255, 69, 212, .4);
            box-shadow: inset 3px 0 0 var(--dragon-pink);
        }

        /* Profile form card */

        .ts-profile-page .form-card {
            position: relative;
            z-index: 1;

            padding: 32px;
            border-radius: 23px;

            background:
                linear-gradient(
                    135deg,
                    rgba(71, 123, 255, .08),
                    rgba(168, 85, 247, .06),
                    rgba(0, 245, 196, .025)
                ),
                var(--dragon-panel);

            border: 1px solid rgba(130, 155, 255, .25);

            box-shadow:
                0 22px 65px rgba(0, 0, 0, .24),
                inset 0 0 35px rgba(71, 123, 255, .025);

            overflow: hidden;

            animation: profile-enter .8s ease both;
        }

        .ts-profile-page .form-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;

            background: linear-gradient(
                90deg,
                var(--dragon-cyan),
                var(--dragon-blue),
                var(--dragon-purple),
                var(--dragon-pink),
                var(--dragon-teal)
            );

            background-size: 200% auto;
            animation: profile-border 7s linear infinite;
        }

        @keyframes profile-border {
            to {
                background-position: 200% center;
            }
        }

        /* Form layout */

        .ts-profile-page .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
            margin-bottom: 22px;
        }

        .ts-profile-page .form-grid > div {
            min-width: 0;
        }

        .ts-profile-page label {
            display: block;
            margin-bottom: 9px;

            color: #dce6ff;
            font-size: 13px;
            font-weight: 750;
        }

        .ts-profile-page input:not([type="file"]),
        .ts-profile-page textarea {
            display: block;
            width: 100%;
            box-sizing: border-box;

            padding: 14px 15px;

            border: 1px solid rgba(127, 155, 255, .22);
            border-radius: 12px;
            outline: none;

            background: rgba(5, 12, 36, .8);
            color: var(--dragon-text);

            font: inherit;
            font-size: 14px;

            transition:
                border-color .25s ease,
                box-shadow .25s ease,
                background .25s ease;
        }

        .ts-profile-page input::placeholder,
        .ts-profile-page textarea::placeholder {
            color: #8495bd;
        }

        .ts-profile-page input:not([type="file"]):focus,
        .ts-profile-page textarea:focus {
            border-color: var(--dragon-cyan);
            background: rgba(12, 24, 62, .95);

            box-shadow:
                0 0 0 3px rgba(0, 229, 255, .08),
                0 0 18px rgba(0, 229, 255, .05);
        }

        .ts-profile-page input:disabled {
            color: #aab7d6;
            background: rgba(25, 34, 72, .65);
            border-color: rgba(127, 155, 255, .13);
            cursor: not-allowed;
            opacity: .85;
        }

        .ts-profile-page textarea {
            min-height: 130px;
            margin-bottom: 23px;
            resize: vertical;
            line-height: 1.7;
        }

        /* Resume input */

        .ts-profile-page input[type="file"] {
            display: block;
            width: 100%;
            box-sizing: border-box;

            padding: 13px;
            margin-bottom: 10px;

            color: var(--dragon-muted);
            background: rgba(5, 12, 36, .8);

            border: 1px dashed rgba(0, 229, 255, .35);
            border-radius: 12px;

            font-size: 13px;
        }

        .ts-profile-page input[type="file"]::file-selector-button {
            padding: 9px 13px;
            margin-right: 12px;

            border: 0;
            border-radius: 8px;

            background: linear-gradient(
                100deg,
                var(--dragon-cyan),
                #b7a3ff
            );

            color: #071522;
            font-weight: 800;
            cursor: pointer;
        }

        .ts-profile-page .small-text {
            margin: 10px 0 23px;
            padding: 12px 14px;

            border-radius: 10px;
            border: 1px solid rgba(0, 245, 196, .2);
            background: rgba(0, 245, 196, .045);

            color: var(--dragon-teal);
            font-size: 12px;
            overflow-wrap: anywhere;
        }

        /* Save profile button */

        .ts-profile-page .btn.primary {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;

            padding: 15px 25px;
            margin-top: 12px;

            border: 0;
            border-radius: 12px;

            background: linear-gradient(
                105deg,
                var(--dragon-teal),
                var(--dragon-cyan),
                #a69aff,
                var(--dragon-pink)
            );

            background-size: 220% auto;

            color: #071522;
            font-size: 14px;
            font-weight: 850;

            cursor: pointer;

            box-shadow: 0 0 22px rgba(0, 229, 255, .13);

            transition:
                transform .25s ease,
                box-shadow .25s ease,
                background-position .4s ease;
        }

        .ts-profile-page .btn.primary::after {
            content: "✦";
            font-size: 16px;
        }

        .ts-profile-page .btn.primary:hover {
            transform: translateY(-3px);
            background-position: right center;
            box-shadow: 0 0 30px rgba(168, 85, 247, .32);
        }

        .ts-profile-page .btn.primary:active {
            transform: translateY(0);
        }

        /* Mobile support */

        @media (max-width: 650px) {
            .ts-profile-page {
                padding: 27px 15px 45px;
            }

            .ts-profile-page .page-heading h1 {
                font-size: clamp(32px, 8vw, 43px);
            }

            .ts-profile-page .form-card {
                padding: 23px 18px;
                border-radius: 18px;
            }

            .ts-profile-page .form-grid {
                grid-template-columns: 1fr;
                gap: 17px;
            }

            .ts-profile-page .btn.primary {
                width: 100%;
                box-sizing: border-box;
            }

            .ts-flying-dragon {
                top: 95px;
                width: 54px;
                height: 40px;
                opacity: .65;
                animation-duration: 28s, 3s;
            }
        }

        /* Respect reduced-motion preferences */

        @media (prefers-reduced-motion: reduce) {
            .ts-profile-page *,
            .ts-profile-space *,
            .ts-flying-dragon,
            .ts-flying-dragon * {
                animation: none !important;
                transition: none !important;
            }

            .ts-flying-dragon {
                display: none;
            }
        }
    </style>
</head>

<body>

<?php include 'student_nav.php'; ?>

<!-- Decorative galaxy stars -->
<div class="ts-profile-space" aria-hidden="true">
    <span class="space-star"></span>
    <span class="space-star"></span>
    <span class="space-star"></span>
    <span class="space-star"></span>
    <span class="space-star"></span>
    <span class="space-star"></span>
</div>

<!-- Small animated dragon -->
<div class="ts-flying-dragon" aria-hidden="true">
    <svg viewBox="0 0 120 85" xmlns="http://www.w3.org/2000/svg">

        <defs>
            <linearGradient id="dragonBody" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stop-color="#70fff0"/>
                <stop offset="45%" stop-color="#00c8ff"/>
                <stop offset="100%" stop-color="#7857ff"/>
            </linearGradient>

            <linearGradient id="dragonWing" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stop-color="#ff62dc"/>
                <stop offset="100%" stop-color="#7c5cff"/>
            </linearGradient>
        </defs>

        <!-- Back wing -->
        <g class="ts-dragon-wing-back">
            <path
                d="M53 42 Q38 17 25 9 L31 27 L14 20
                   Q22 37 43 51 Z"
                fill="url(#dragonWing)"
                stroke="#e5b4ff"
                stroke-width="1.3"
            />
        </g>

        <!-- Tail -->
        <g class="ts-dragon-tail">
            <path
                d="M40 51 Q23 58 15 48 Q24 65 39 58"
                fill="none"
                stroke="url(#dragonBody)"
                stroke-width="5"
                stroke-linecap="round"
            />
            <path
                d="M16 48 L8 43 L12 54 Z"
                fill="#ff62dc"
            />
        </g>

        <!-- Main wing -->
        <g class="ts-dragon-wing">
            <path
                d="M52 43 Q58 12 80 5 L75 24
                   L98 17 Q89 38 68 51 Z"
                fill="url(#dragonWing)"
                stroke="#f0b7ff"
                stroke-width="1.4"
            />

            <path
                d="M57 43 L75 24 M65 47 L89 38"
                fill="none"
                stroke="#f8c9ff"
                stroke-width="1"
                opacity=".8"
            />
        </g>

        <!-- Dragon body -->
        <path
            d="M36 44
               Q49 33 65 39
               Q78 44 86 40
               L101 35
               Q107 34 109 40
               L101 47
               L109 53
               Q96 60 82 54
               Q62 66 42 55 Z"
            fill="url(#dragonBody)"
            stroke="#b9fff8"
            stroke-width="1.3"
        />

        <!-- Little horns -->
        <path
            d="M89 39 L87 29 L96 37
               M99 39 L104 31 L105 42"
            fill="#ffb5ed"
            stroke="#ffb5ed"
            stroke-width="2"
            stroke-linejoin="round"
        />

        <!-- Face -->
        <circle cx="101" cy="42" r="2.4" fill="#071522"/>
        <circle cx="102" cy="41" r=".8" fill="#ffffff"/>

        <!-- Smile -->
        <path
            d="M103 48 Q108 50 110 46"
            fill="none"
            stroke="#15316c"
            stroke-width="1.3"
            stroke-linecap="round"
        />

        <!-- Tiny glowing fire breath -->
        <path
            d="M110 49 Q117 51 112 55 Q120 54 117 48"
            fill="#ffae57"
            opacity=".9"
        />

        <!-- Small sparkle -->
        <path
            d="M21 28 L23 34 L29 36 L23 38 L21 44
               L19 38 L13 36 L19 34 Z"
            fill="#ffffff"
            opacity=".9"
        />

    </svg>
</div>

<main class="dashboard narrow ts-profile-page">

    <div class="page-heading">
        <div>
            <p class="eyebrow">YOUR PROFILE</p>

            <h1>Make your profile count.</h1>

            <p>
                Strong profiles make it easier for companies
                to understand your skills.
            </p>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert <?= $messageType === 'success' ? 'success' : 'error' ?>">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <div class="form-card">

        <form method="POST" enctype="multipart/form-data">

            <div class="form-grid">

                <div>
                    <label for="profile-name">Name</label>
                    <input
                        id="profile-name"
                        value="<?= e($user['name'] ?? '') ?>"
                        disabled
                    >
                </div>

                <div>
                    <label for="profile-email">Email</label>
                    <input
                        id="profile-email"
                        value="<?= e($user['email'] ?? '') ?>"
                        disabled
                    >
                </div>

                <div>
                    <label for="profile-phone">Phone</label>
                    <input
                        id="profile-phone"
                        name="phone"
                        value="<?= e($student['phone'] ?? '') ?>"
                        placeholder="+91..."
                    >
                </div>

                <div>
                    <label for="profile-college">College</label>
                    <input
                        id="profile-college"
                        name="college"
                        value="<?= e($student['college'] ?? '') ?>"
                        placeholder="College / University"
                    >
                </div>

                <div>
                    <label for="profile-course">Course</label>
                    <input
                        id="profile-course"
                        name="course"
                        value="<?= e($student['course'] ?? '') ?>"
                        placeholder="B.E. Computer Science"
                    >
                </div>

                <div>
                    <label for="profile-skills">Skills</label>
                    <input
                        id="profile-skills"
                        name="skills"
                        value="<?= e($student['skills'] ?? '') ?>"
                        placeholder="PHP, JavaScript, MySQL"
                    >
                </div>

            </div>

            <label for="profile-bio">About you</label>

            <textarea
                id="profile-bio"
                name="bio"
                rows="5"
                placeholder="A short introduction..."
            ><?= e($student['bio'] ?? '') ?></textarea>

            <label for="profile-resume">
                Resume (PDF, max 5 MB)
            </label>

            <input
                id="profile-resume"
                type="file"
                name="resume"
                accept="application/pdf,.pdf"
            >

            <?php if (!empty($student['resume'])): ?>
                <p class="small-text">
                    Resume uploaded: <?= e($student['resume']) ?>
                </p>
            <?php endif; ?>

            <button class="btn primary" type="submit">
                Save profile
            </button>

        </form>

    </div>

</main>

</body>
</html>