<?php
session_start();

require_once __DIR__ . '/../config/database.php';

require_role('student');

$data = db_load();

$search = trim($_GET['search'] ?? '');
$location = trim($_GET['location'] ?? '');

$rows = [];

foreach ($data['internships'] as $i) {
    if (($i['status'] ?? 'Open') !== 'Open') {
        continue;
    }

    $c = db_company($data, (int) $i['company_id']);

    if (!$c) {
        continue;
    }

    $hay = strtolower(
        $i['title'] . ' ' .
        $i['description'] . ' ' .
        $c['company_name']
    );

    if (
        $search !== '' &&
        strpos($hay, strtolower($search)) === false
    ) {
        continue;
    }

    if (
        $location !== '' &&
        stripos($i['location'], $location) === false
    ) {
        continue;
    }

    $i['company_name'] = $c['company_name'];
    $rows[] = $i;
}

db_sort_newest($rows);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Internships · TalentSprint</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>
        /* All new styles are scoped to this page. */

        body:has(.ts-internships-page) {
            --space-bg: #07091b;
            --space-panel: rgba(12, 20, 55, .92);
            --space-cyan: #00e5ff;
            --space-teal: #00f5c4;
            --space-blue: #477bff;
            --space-purple: #a855f7;
            --space-pink: #ff45d4;
            --space-orange: #ffae57;
            --space-text: #f8faff;
            --space-muted: #b4bfdc;

            min-height: 100vh;
            color: var(--space-text);

            background:
                radial-gradient(
                    ellipse at 12% 12%,
                    rgba(71, 123, 255, .18),
                    transparent 35%
                ),
                radial-gradient(
                    ellipse at 88% 30%,
                    rgba(168, 85, 247, .15),
                    transparent 35%
                ),
                radial-gradient(
                    ellipse at 50% 100%,
                    rgba(0, 245, 196, .08),
                    transparent 40%
                ),
                var(--space-bg);

            overflow-x: hidden;
        }

        .ts-internships-page {
            position: relative;
            isolation: isolate;
            max-width: 1350px;
            margin: 0 auto;
            padding: 42px 28px 75px;
        }

        /* Galaxy background */

        .ts-galaxy-bg {
            position: fixed;
            inset: 0;
            z-index: -1;
            overflow: hidden;
            pointer-events: none;
        }

        .ts-galaxy-bg .star {
            position: absolute;
            width: 3px;
            height: 3px;
            border-radius: 50%;
            background: white;
            box-shadow: 0 0 10px var(--space-cyan);
            animation: ts-twinkle 3s ease-in-out infinite alternate;
        }

        .ts-galaxy-bg .star:nth-child(1) {
            top: 12%;
            left: 10%;
        }

        .ts-galaxy-bg .star:nth-child(2) {
            top: 25%;
            left: 84%;
            animation-delay: .7s;
        }

        .ts-galaxy-bg .star:nth-child(3) {
            top: 55%;
            left: 7%;
            animation-delay: 1.3s;
        }

        .ts-galaxy-bg .star:nth-child(4) {
            top: 72%;
            left: 90%;
            animation-delay: 1.8s;
        }

        .ts-galaxy-bg .star:nth-child(5) {
            top: 88%;
            left: 34%;
            animation-delay: 2.2s;
        }

        .ts-galaxy-bg .star:nth-child(6) {
            top: 40%;
            left: 58%;
            animation-delay: .5s;
        }

        .ts-galaxy-bg .shooting-star {
            position: absolute;
            top: 12%;
            left: 110%;
            width: 125px;
            height: 2px;
            opacity: 0;
            transform: rotate(-35deg);

            background: linear-gradient(
                90deg,
                transparent,
                var(--space-cyan),
                white
            );

            filter: drop-shadow(0 0 5px var(--space-cyan));
            animation: ts-shoot 10s linear infinite;
        }

        .ts-galaxy-bg .shooting-star:nth-child(8) {
            top: 45%;
            animation-delay: 3s;
            animation-duration: 12s;
        }

        .ts-galaxy-bg .shooting-star:nth-child(9) {
            top: 75%;
            animation-delay: 6s;
            animation-duration: 11s;
        }

        @keyframes ts-twinkle {
            from {
                opacity: .2;
                transform: scale(.7);
            }

            to {
                opacity: 1;
                transform: scale(1.5);
            }
        }

        @keyframes ts-shoot {
            0% {
                left: 110%;
                opacity: 0;
            }

            5% {
                opacity: 1;
            }

            20% {
                left: -25%;
                opacity: 0;
            }

            100% {
                left: -25%;
                opacity: 0;
            }
        }

        /* Floating decorative planet */

        .ts-planet {
            position: absolute;
            top: 35px;
            right: 65px;
            width: 85px;
            height: 85px;
            border-radius: 50%;

            background: radial-gradient(
                circle at 32% 27%,
                #f3e8ff,
                #c084fc 12%,
                #7c3aed 32%,
                #312e81 63%,
                #111735 82%
            );

            box-shadow:
                0 0 22px rgba(168, 85, 247, .45),
                0 0 55px rgba(71, 123, 255, .18),
                inset -12px -8px 18px rgba(0, 0, 30, .6);

            animation: ts-planet-float 5s ease-in-out infinite;
            pointer-events: none;
        }

        .ts-planet::before {
            content: "";
            position: absolute;
            width: 112px;
            height: 24px;
            left: -14px;
            top: 30px;
            border: 2px solid var(--space-cyan);
            border-radius: 50%;
            transform: rotate(-25deg);
            box-shadow: 0 0 12px rgba(0, 229, 255, .3);
        }

        .ts-planet::after {
            content: "";
            position: absolute;
            top: 75px;
            left: 96px;
            width: 13px;
            height: 13px;
            border-radius: 50%;
            background: radial-gradient(circle at 30% 25%, #fff, #9aa9d7);
            box-shadow: 0 0 12px rgba(255, 255, 255, .5);
        }

        @keyframes ts-planet-float {
            0%, 100% {
                transform: translateY(0) rotate(0deg);
            }

            50% {
                transform: translateY(-9px) rotate(5deg);
            }
        }

        /* Hero heading */

        .ts-internships-page .page-heading {
            position: relative;
            padding: 20px 0 25px;
            margin-bottom: 20px;
            animation: ts-enter .7s ease both;
        }

        .ts-internships-page .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            margin: 0 0 18px;
            padding: 10px 16px;

            color: var(--space-cyan);
            background: rgba(0, 229, 255, .06);
            border: 1px solid rgba(0, 229, 255, .3);
            border-radius: 30px;

            font-size: 11px;
            font-weight: 850;
            letter-spacing: 2px;
        }

        .ts-internships-page .eyebrow::before {
            content: "";
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--space-cyan);
            box-shadow: 0 0 10px var(--space-cyan);
            animation: ts-pulse 2s ease-in-out infinite;
        }

        .ts-internships-page .page-heading h1 {
            max-width: 780px;
            margin: 0 0 15px;
            font-size: clamp(37px, 5vw, 64px);
            line-height: 1.12;
            font-weight: 900;
            letter-spacing: -1.5px;

            background: linear-gradient(
                90deg,
                #fff 0%,
                var(--space-cyan) 30%,
                var(--space-purple) 62%,
                var(--space-pink) 82%,
                var(--space-orange) 100%
            );

            background-size: 220% auto;
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;

            animation: ts-gradient 8s linear infinite;
        }

        .ts-internships-page .page-heading p:not(.eyebrow) {
            color: var(--space-muted);
            font-size: 16px;
            line-height: 1.8;
            margin: 0;
        }

        @keyframes ts-gradient {
            to {
                background-position: 220% center;
            }
        }

        @keyframes ts-pulse {
            0%, 100% {
                opacity: 1;
                transform: scale(1);
            }

            50% {
                opacity: .45;
                transform: scale(.8);
            }
        }

        @keyframes ts-enter {
            from {
                opacity: 0;
                transform: translateY(15px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Search form */

        .ts-internships-page .search-bar {
            display: grid;
            grid-template-columns: minmax(0, 1.2fr) minmax(0, 1fr) auto;
            gap: 12px;
            padding: 14px;
            margin: 12px 0 36px;

            background: rgba(9, 17, 49, .9);
            border: 1px solid rgba(0, 145, 255, .45);
            border-radius: 19px;

            box-shadow:
                0 12px 35px rgba(0, 0, 0, .2),
                inset 0 0 22px rgba(71, 123, 255, .04);

            animation: ts-enter .85s ease both;
        }

        .ts-internships-page .search-bar input {
            width: 100%;
            min-width: 0;
            box-sizing: border-box;
            padding: 16px 18px;

            border: 1px solid rgba(116, 153, 255, .22);
            border-radius: 12px;
            outline: none;

            background: rgba(5, 13, 40, .85);
            color: var(--space-text);
            font: inherit;

            transition:
                border-color .25s ease,
                box-shadow .25s ease,
                background .25s ease;
        }

        .ts-internships-page .search-bar input::placeholder {
            color: #9aaed8;
        }

        .ts-internships-page .search-bar input:focus {
            border-color: var(--space-cyan);
            background: rgba(12, 26, 66, .95);
            box-shadow: 0 0 0 3px rgba(0, 229, 255, .09);
        }

        .ts-internships-page .btn.primary {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;

            padding: 14px 25px;
            border: 0;
            border-radius: 12px;

            color: #071522;
            background: linear-gradient(
                110deg,
                var(--space-cyan),
                var(--space-blue),
                var(--space-purple),
                var(--space-pink)
            );

            background-size: 200% auto;
            font-weight: 850;
            text-decoration: none;
            white-space: nowrap;
            cursor: pointer;

            box-shadow: 0 0 20px rgba(0, 229, 255, .12);

            transition:
                transform .25s ease,
                box-shadow .25s ease,
                background-position .4s ease;
        }

        .ts-internships-page .btn.primary:hover {
            transform: translateY(-3px);
            background-position: right center;
            box-shadow: 0 0 28px rgba(168, 85, 247, .3);
        }

        /* Internship grid */

        .ts-internships-page .internship-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 22px;
        }

        /* Internship cards */

        .ts-internships-page .internship-card {
            --card-accent: var(--space-cyan);

            position: relative;
            display: flex;
            flex-direction: column;
            min-width: 0;

            padding: 25px;
            border-radius: 19px;
            overflow: hidden;

            background:
                linear-gradient(
                    145deg,
                    rgba(20, 31, 77, .94),
                    rgba(8, 15, 44, .96)
                );

            border: 1px solid color-mix(
                in srgb,
                var(--card-accent) 70%,
                transparent
            );

            box-shadow:
                0 12px 35px rgba(0, 0, 0, .2),
                inset 0 0 30px rgba(71, 123, 255, .025);

            transition:
                transform .3s ease,
                box-shadow .3s ease,
                border-color .3s ease;

            animation: ts-card-enter .6s ease both;
        }

        .ts-internships-page .internship-card:nth-child(6n + 2) {
            --card-accent: var(--space-purple);
        }

        .ts-internships-page .internship-card:nth-child(6n + 3) {
            --card-accent: var(--space-pink);
        }

        .ts-internships-page .internship-card:nth-child(6n + 4) {
            --card-accent: #ff66bb;
        }

        .ts-internships-page .internship-card:nth-child(6n + 5) {
            --card-accent: var(--space-teal);
        }

        .ts-internships-page .internship-card:nth-child(6n) {
            --card-accent: var(--space-orange);
        }

        .ts-internships-page .internship-card:nth-child(1) {
            animation-delay: .05s;
        }

        .ts-internships-page .internship-card:nth-child(2) {
            animation-delay: .12s;
        }

        .ts-internships-page .internship-card:nth-child(3) {
            animation-delay: .19s;
        }

        .ts-internships-page .internship-card:nth-child(4) {
            animation-delay: .26s;
        }

        .ts-internships-page .internship-card:nth-child(5) {
            animation-delay: .33s;
        }

        .ts-internships-page .internship-card:nth-child(6) {
            animation-delay: .4s;
        }

        @keyframes ts-card-enter {
            from {
                opacity: 0;
                transform: translateY(15px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .ts-internships-page .internship-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(
                90deg,
                var(--card-accent),
                transparent
            );
        }

        .ts-internships-page .internship-card::after {
            content: "";
            position: absolute;
            width: 150px;
            height: 150px;
            right: -95px;
            bottom: -100px;
            border-radius: 50%;
            background: var(--card-accent);
            opacity: .08;
            filter: blur(20px);
            pointer-events: none;
            transition: opacity .3s ease;
        }

        .ts-internships-page .internship-card:hover {
            transform: translateY(-7px);
            border-color: var(--card-accent);
            box-shadow:
                0 18px 42px rgba(0, 0, 0, .3),
                0 0 22px color-mix(
                    in srgb,
                    var(--card-accent) 15%,
                    transparent
                );
        }

        .ts-internships-page .internship-card:hover::after {
            opacity: .2;
        }

        /* Open badge */

        .ts-internships-page .status.open {
            display: inline-flex;
            align-items: center;
            align-self: flex-start;
            gap: 7px;

            padding: 7px 11px;
            margin-bottom: 17px;

            color: var(--space-teal);
            background: rgba(0, 245, 196, .08);
            border: 1px solid rgba(0, 245, 196, .25);
            border-radius: 25px;

            font-size: 11px;
            font-weight: 850;
            letter-spacing: .5px;
        }

        .ts-internships-page .status.open::before {
            content: "";
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: var(--space-teal);
            box-shadow: 0 0 8px var(--space-teal);
        }

        /* Internship title and company */

        .ts-internships-page .internship-card h2 {
            margin: 0 0 9px;
            color: var(--space-text);
            font-size: 21px;
            font-weight: 800;
            line-height: 1.4;
            overflow-wrap: anywhere;
        }

        .ts-internships-page .internship-card h4 {
            margin: 0 0 15px;
            color: var(--card-accent);
            font-size: 14px;
            font-weight: 750;
            overflow-wrap: anywhere;
        }

        .ts-internships-page .internship-card > p {
            flex: 1;
            margin: 0 0 22px;
            color: var(--space-muted);
            font-size: 14px;
            line-height: 1.8;
            overflow-wrap: anywhere;
        }

        /* Tags */

        .ts-internships-page .tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 22px;
        }

        .ts-internships-page .tags span {
            display: inline-flex;
            align-items: center;
            max-width: 100%;
            padding: 7px 10px;

            color: #dce8ff;
            background: rgba(71, 123, 255, .1);
            border: 1px solid rgba(116, 153, 255, .2);
            border-radius: 25px;

            font-size: 11px;
            line-height: 1.5;
            overflow-wrap: anywhere;
        }

        .ts-internships-page .tags span:nth-child(2) {
            color: #c8b5ff;
            background: rgba(168, 85, 247, .1);
            border-color: rgba(168, 85, 247, .23);
        }

        .ts-internships-page .tags span:nth-child(3) {
            color: var(--space-teal);
            background: rgba(0, 245, 196, .07);
            border-color: rgba(0, 245, 196, .2);
        }

        /* Full-width card action */

        .ts-internships-page .internship-card .btn.primary {
            width: 100%;
            box-sizing: border-box;
            margin-top: auto;
            padding: 13px 15px;
            font-size: 13px;
            text-align: center;
        }

        /* Empty search results */

        .ts-internships-page .table-card.empty {
            grid-column: 1 / -1;
            padding: 35px;
            border: 1px solid rgba(0, 229, 255, .25);
            border-radius: 18px;
            background: var(--space-panel);
            color: var(--space-muted);
            text-align: center;
            animation: ts-enter .5s ease both;
        }

        /* Responsive layout */

        @media (max-width: 1000px) {
            .ts-internships-page .internship-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .ts-planet {
                right: 35px;
                transform: scale(.8);
            }

            .ts-internships-page .page-heading h1 {
                max-width: 75%;
            }
        }

        @media (max-width: 650px) {
            .ts-internships-page {
                padding: 25px 15px 45px;
            }

            .ts-internships-page .page-heading {
                padding-top: 10px;
            }

            .ts-internships-page .page-heading h1 {
                max-width: 100%;
                font-size: clamp(34px, 9vw, 46px);
                letter-spacing: -.7px;
            }

            .ts-internships-page .page-heading p:not(.eyebrow) {
                max-width: 90%;
                font-size: 14px;
            }

            .ts-planet {
                top: 5px;
                right: 5px;
                transform: scale(.55);
                transform-origin: top right;
                opacity: .65;
            }

            .ts-internships-page .search-bar {
                grid-template-columns: 1fr;
                gap: 10px;
                padding: 12px;
                margin-bottom: 25px;
            }

            .ts-internships-page .search-bar input,
            .ts-internships-page .search-bar .btn {
                width: 100%;
                min-height: 48px;
                box-sizing: border-box;
            }

            .ts-internships-page .internship-grid {
                grid-template-columns: 1fr;
                gap: 17px;
            }

            .ts-internships-page .internship-card {
                padding: 22px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            .ts-internships-page *,
            .ts-galaxy-bg * {
                animation: none !important;
                transition: none !important;
            }
        }
    </style>
</head>

<body>

<?php include 'student_nav.php'; ?>

<div class="ts-galaxy-bg" aria-hidden="true">
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>

    <span class="shooting-star"></span>
    <span class="shooting-star"></span>
    <span class="shooting-star"></span>
</div>

<main class="dashboard ts-internships-page">

    <div class="ts-planet" aria-hidden="true"></div>

    <div class="page-heading">
        <div>
            <p class="eyebrow">OPPORTUNITIES</p>

            <h1>Find your next role.</h1>

            <p>
                Search open internships by role, company or location.
            </p>
        </div>
    </div>

    <form class="search-bar" method="GET">

        <input
            type="text"
            name="search"
            value="<?= e($search) ?>"
            placeholder="Role, company or keyword"
            aria-label="Search by role, company or keyword"
        >

        <input
            type="text"
            name="location"
            value="<?= e($location) ?>"
            placeholder="Location"
            aria-label="Search by location"
        >

        <button class="btn primary" type="submit">
            Search →
        </button>

    </form>

    <div class="internship-grid">

        <?php if (!$rows): ?>

            <div class="table-card empty">
                No matching internships found. Try another search.
            </div>

        <?php else: ?>

            <?php foreach ($rows as $row): ?>

                <article class="internship-card">

                    <span class="status open">Open</span>

                    <h2><?= e($row['title']) ?></h2>

                    <h4><?= e($row['company_name']) ?></h4>

                    <p><?= e($row['description']) ?></p>

                    <div class="tags">

                        <span>
                            <?= e($row['location']) ?>
                        </span>

                        <?php if (!empty($row['skills'])): ?>
                            <span>
                                <?= e($row['skills']) ?>
                            </span>
                        <?php endif; ?>

                        <?php if (!empty($row['duration'])): ?>
                            <span>
                                <?= e($row['duration']) ?>
                            </span>
                        <?php endif; ?>

                    </div>

                    <a
                        class="btn primary"
                        href="apply.php?id=<?= (int) $row['id'] ?>"
                    >
                        View &amp; apply →
                    </a>

                </article>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

</main>

</body>
</html>