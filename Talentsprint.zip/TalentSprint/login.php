<?php
session_start();

require_once __DIR__ . '/config/database.php';

$data = db_load();
$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    $user = db_find_user_by_email($data, $email);

    if (!$user || !password_verify($password, $user['password'])) {
        $error = 'Invalid email or password.';
    } else {
        session_regenerate_id(true);

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];

        header(
            'Location: ' .
            ($user['role'] === 'student'
                ? 'student/dashboard.php'
                : 'company/dashboard.php')
        );

        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Sign In | TalentSprint</title>

    <link rel="stylesheet" href="css/style.css">

    <style>
        :root {
            --login-bg: #080b19;
            --login-card: rgba(19, 23, 47, 0.88);

            --cyan: #00f5d4;
            --blue: #00c2ff;
            --indigo: #4f7dff;
            --purple: #a855f7;
            --pink: #ff4fd8;
            --orange: #ffab5e;

            --white: #ffffff;
            --muted: #a8b3d0;
        }

        /* =====================================
           PAGE BACKGROUND
        ===================================== */

        body.auth-page {
            min-height: 100vh;
            margin: 0;
            padding: 35px 5%;
            box-sizing: border-box;

            display: flex;
            align-items: center;
            justify-content: center;

            position: relative;
            isolation: isolate;
            overflow-x: hidden;

            color: var(--white);
            background:
                radial-gradient(
                    ellipse at 12% 15%,
                    rgba(168, 85, 247, 0.20),
                    transparent 36%
                ),
                radial-gradient(
                    ellipse at 88% 18%,
                    rgba(0, 194, 255, 0.16),
                    transparent 32%
                ),
                radial-gradient(
                    ellipse at 80% 90%,
                    rgba(255, 79, 216, 0.12),
                    transparent 35%
                ),
                linear-gradient(
                    135deg,
                    #10152e 0%,
                    #080b19 55%,
                    #15102a 100%
                );

            font-family: Inter, "Segoe UI", Arial, sans-serif;
        }

        body.auth-page *,
        body.auth-page *::before,
        body.auth-page *::after {
            box-sizing: border-box;
        }

        body.auth-page a {
            text-decoration: none;
        }

        /* Decorative background orbs */

        .login-orb {
            position: fixed;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            filter: blur(100px);
            opacity: 0.18;
            pointer-events: none;
            z-index: -1;
            animation: floatOrb 10s ease-in-out infinite alternate;
        }

        .login-orb.orb-purple {
            top: 4%;
            left: -100px;
            background: var(--purple);
        }

        .login-orb.orb-cyan {
            top: 30%;
            right: -100px;
            background: var(--blue);
            animation-delay: -3s;
        }

        .login-orb.orb-pink {
            bottom: -140px;
            left: 35%;
            background: var(--pink);
            animation-delay: -5s;
        }

        @keyframes floatOrb {
            from {
                transform: translate3d(0, 0, 0) scale(1);
            }

            to {
                transform: translate3d(25px, -25px, 0) scale(1.12);
            }
        }

        /* =====================================
           MAIN LAYOUT
        ===================================== */

        .auth-page .auth-container {
            width: 100%;
            max-width: 1120px;
            margin: auto;

            display: grid;
            grid-template-columns: minmax(0, 1fr) 430px;
            align-items: center;
            gap: clamp(45px, 7vw, 100px);

            position: relative;
            z-index: 1;
        }

        /* =====================================
           LEFT BRANDING PANEL
        ===================================== */

        .auth-page .auth-brand {
            color: var(--white);
            padding: 20px 0;
        }

        .auth-page .auth-brand .logo {
            display: inline-flex;
            align-items: center;
            gap: 2px;

            color: var(--white);
            font-size: 31px;
            font-weight: 900;
            letter-spacing: -1.5px;

            transition: transform 0.25s ease;
        }

        .auth-page .auth-brand .logo:hover {
            transform: translateY(-2px);
        }

        .auth-page .auth-brand .logo span {
            background: linear-gradient(
                90deg,
                var(--cyan),
                var(--blue),
                var(--purple),
                var(--pink)
            );

            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* Welcome badge */

        .auth-page .auth-brand .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 9px;

            margin: 65px 0 22px !important;
            padding: 10px 16px;

            color: var(--cyan);
            background: linear-gradient(
                100deg,
                rgba(0, 245, 212, 0.09),
                rgba(79, 125, 255, 0.09),
                rgba(168, 85, 247, 0.09)
            );

            border: 1px solid rgba(0, 245, 212, 0.24);
            border-radius: 30px;

            font-size: 11px;
            font-weight: 800;
            letter-spacing: 2.5px;
        }

        .auth-page .auth-brand .eyebrow::before {
            content: "✦";
            color: var(--pink);
            font-size: 15px;
        }

        /* Main headline */

        .auth-page .auth-brand h1 {
            max-width: 560px;
            margin: 0 0 24px;

            color: var(--white);
            font-size: clamp(42px, 5vw, 66px);
            line-height: 1.08;
            letter-spacing: -2.5px;
            font-weight: 900;
        }

        .auth-page .auth-brand h1 span {
            display: block;

            background: linear-gradient(
                90deg,
                var(--cyan) 0%,
                var(--blue) 28%,
                var(--purple) 58%,
                var(--pink) 82%,
                var(--orange) 100%
            );

            background-size: 200% auto;
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;

            animation: headlineGradient 7s ease-in-out infinite alternate;
        }

        @keyframes headlineGradient {
            from {
                background-position: 0% center;
            }

            to {
                background-position: 100% center;
            }
        }

        .auth-page .auth-brand > p:last-child {
            max-width: 450px;
            margin: 0;

            color: var(--muted);
            font-size: 16px;
            line-height: 1.9;
        }

        /* Left-side benefit list */

        .login-benefits {
            display: grid;
            gap: 17px;
            margin-top: 35px;
        }

        .login-benefit {
            display: flex;
            align-items: center;
            gap: 13px;

            color: #d9e2fa;
            font-size: 14px;
        }

        .login-benefit-icon {
            width: 35px;
            height: 35px;
            flex-shrink: 0;

            display: flex;
            align-items: center;
            justify-content: center;

            border: 1px solid rgba(0, 245, 212, 0.22);
            border-radius: 11px;

            background: linear-gradient(
                135deg,
                rgba(0, 245, 212, 0.12),
                rgba(79, 125, 255, 0.13)
            );

            color: var(--cyan);
            font-size: 16px;
        }

        /* =====================================
           LOGIN CARD
        ===================================== */

        .auth-page .auth-card {
            width: 100%;
            padding: 38px 34px;

            position: relative;
            overflow: hidden;

            color: var(--white);
            background: var(--login-card);

            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 27px;

            box-shadow:
                0 30px 90px rgba(0, 0, 0, 0.35),
                0 0 45px rgba(79, 125, 255, 0.06);

            backdrop-filter: blur(24px);
            -webkit-backdrop-filter: blur(24px);

            animation: cardAppear 0.65s ease both;
        }

        /* Multicolor line at top of card */

        .auth-page .auth-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;

            background: linear-gradient(
                90deg,
                var(--cyan),
                var(--blue),
                var(--purple),
                var(--pink),
                var(--orange)
            );
        }

        .auth-page .auth-card::after {
            content: "";
            position: absolute;
            top: -100px;
            right: -100px;

            width: 200px;
            height: 200px;

            background: var(--purple);
            filter: blur(90px);
            opacity: 0.14;
            pointer-events: none;
        }

        @keyframes cardAppear {
            from {
                opacity: 0;
                transform: translateY(18px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Card icon */

        .login-card-icon {
            width: 58px;
            height: 58px;
            margin-bottom: 24px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 18px;

            color: var(--white);
            font-size: 26px;

            background: linear-gradient(
                135deg,
                rgba(0, 245, 212, 0.20),
                rgba(79, 125, 255, 0.24),
                rgba(168, 85, 247, 0.25)
            );

            border: 1px solid rgba(255, 255, 255, 0.12);
            box-shadow: 0 10px 30px rgba(79, 125, 255, 0.12);
        }

        .auth-page .auth-card h2 {
            margin: 0 0 10px;

            color: var(--white);
            font-size: 32px;
            font-weight: 850;
            letter-spacing: -1px;
        }

        .auth-page .auth-card .muted {
            margin: 0 0 27px;

            color: var(--muted);
            font-size: 14px;
            line-height: 1.7;
        }

        /* =====================================
           LOGIN FORM
        ===================================== */

        .auth-page .auth-card form label {
            display: block;
            margin: 19px 0 9px;

            color: #e0e7ff;
            font-size: 13px;
            font-weight: 700;
        }

        .auth-page .auth-card form input {
            display: block;
            width: 100%;
            min-height: 51px;
            padding: 13px 15px;

            border: 1px solid rgba(255, 255, 255, 0.13);
            border-radius: 12px;

            background: rgba(255, 255, 255, 0.045);
            color: var(--white);

            font-family: inherit;
            font-size: 14px;

            outline: none;

            transition:
                border-color 0.25s ease,
                background 0.25s ease,
                box-shadow 0.25s ease;
        }

        .auth-page .auth-card form input::placeholder {
            color: #7783a3;
        }

        .auth-page .auth-card form input:hover {
            border-color: rgba(255, 255, 255, 0.24);
        }

        .auth-page .auth-card form input:focus {
            border-color: var(--neon-cyan);
            background: rgba(0, 194, 255, 0.045);

            box-shadow:
                0 0 0 3px rgba(0, 194, 255, 0.10),
                0 0 22px rgba(0, 194, 255, 0.05);
        }

        /* Submit button */

        .auth-page .auth-card form button.btn.primary.full {
            width: 100%;
            min-height: 53px;
            margin-top: 27px;
            padding: 13px 18px;

            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;

            border: none;
            border-radius: 13px;

            background: linear-gradient(
                110deg,
                var(--cyan),
                var(--blue),
                var(--purple),
                var(--pink)
            );

            background-size: 200% 200%;

            color: #ffffff;
            font-family: inherit;
            font-size: 15px;
            font-weight: 800;

            cursor: pointer;

            box-shadow: 0 10px 28px rgba(79, 125, 255, 0.23);

            transition:
                transform 0.25s ease,
                box-shadow 0.25s ease,
                background-position 0.4s ease;
        }

        .auth-page .auth-card form button.btn.primary.full::after {
            content: "→";
            font-size: 20px;
            line-height: 1;
        }

        .auth-page .auth-card form button.btn.primary.full:hover {
            transform: translateY(-3px);
            background-position: 100% 50%;

            box-shadow:
                0 14px 35px rgba(168, 85, 247, 0.25),
                0 0 22px rgba(0, 194, 255, 0.10);
        }

        .auth-page .auth-card form button.btn.primary.full:active {
            transform: translateY(-1px);
        }

        /* Error message */

        .auth-page .auth-card .alert.error {
            position: relative;
            z-index: 1;

            margin: 16px 0;
            padding: 13px 15px;

            border: 1px solid rgba(255, 100, 120, 0.30);
            border-radius: 12px;

            background: rgba(255, 70, 100, 0.10);
            color: #ffb4c0;

            font-size: 13px;
            line-height: 1.6;
        }

        /* Bottom registration link */

        .auth-page .auth-card .auth-bottom {
            margin: 26px 0 0;
            padding-top: 22px;

            border-top: 1px solid rgba(255, 255, 255, 0.09);

            color: var(--muted);
            text-align: center;
            font-size: 13px;
        }

        .auth-page .auth-card .auth-bottom a {
            color: var(--cyan);
            font-weight: 800;
            text-decoration: none;

            transition: color 0.2s ease;
        }

        .auth-page .auth-card .auth-bottom a:hover {
            color: var(--pink);
            text-decoration: underline;
        }

        .login-secure-note {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;

            margin-top: 18px;

            color: #8995b4;
            font-size: 11px;
        }

        .login-secure-note span {
            color: var(--cyan);
        }

        /* =====================================
           TABLET
        ===================================== */

        @media (max-width: 900px) {
            body.auth-page {
                padding: 35px 5%;
            }

            .auth-page .auth-container {
                max-width: 520px;
                grid-template-columns: 1fr;
                gap: 30px;
            }

            .auth-page .auth-brand {
                padding: 0;
                text-align: center;
            }

            .auth-page .auth-brand .eyebrow {
                margin-top: 28px !important;
            }

            .auth-page .auth-brand h1 {
                max-width: 500px;
                margin-left: auto;
                margin-right: auto;

                font-size: clamp(38px, 7vw, 52px);
                letter-spacing: -1.5px;
            }

            .auth-page .auth-brand > p:last-child {
                margin-left: auto;
                margin-right: auto;
            }

            .login-benefits {
                max-width: 350px;
                margin: 25px auto 0;
                text-align: left;
            }

            .auth-page .auth-card {
                padding: 35px 30px;
            }
        }

        /* =====================================
           MOBILE
        ===================================== */

        @media (max-width: 480px) {
            body.auth-page {
                padding: 25px 16px;
            }

            .auth-page .auth-brand .logo {
                font-size: 27px;
            }

            .auth-page .auth-brand .eyebrow {
                margin-top: 25px !important;
                font-size: 10px;
                letter-spacing: 2px;
            }

            .auth-page .auth-brand h1 {
                font-size: 37px;
            }

            .auth-page .auth-brand > p:last-child {
                font-size: 14px;
            }

            .login-benefits {
                gap: 13px;
                margin-top: 22px;
            }

            .login-benefit {
                font-size: 12px;
            }

            .auth-page .auth-card {
                padding: 30px 22px;
                border-radius: 22px;
            }

            .login-card-icon {
                width: 51px;
                height: 51px;
                margin-bottom: 20px;
                border-radius: 15px;
            }

            .auth-page .auth-card h2 {
                font-size: 28px;
            }
        }

        /* Accessibility */

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }
    </style>
</head>

<body class="auth-page">

    <!-- Decorative background elements -->
    <div class="login-orb orb-purple" aria-hidden="true"></div>
    <div class="login-orb orb-cyan" aria-hidden="true"></div>
    <div class="login-orb orb-pink" aria-hidden="true"></div>

    <div class="auth-container">

        <!-- Left branding section -->
        <section class="auth-brand">

            <a href="index.php" class="logo">
                Talent<span>Sprint</span>
            </a>

            <p class="eyebrow">WELCOME BACK</p>

            <h1>
                Your next
                <span>opportunity</span>
                is waiting.
            </h1>

            <p>
                Your future starts with one step. Sign in to discover
                internships, showcase your skills, and move closer
                to your dream career.
            </p>

            <div class="login-benefits">

                <div class="login-benefit">
                    <div class="login-benefit-icon">✦</div>
                    <span>Discover opportunities that match your skills</span>
                </div>

                <div class="login-benefit">
                    <div class="login-benefit-icon">↗</div>
                    <span>Track your applications in one place</span>
                </div>

                <div class="login-benefit">
                    <div class="login-benefit-icon">✓</div>
                    <span>Connect with companies and grow your career</span>
                </div>

            </div>

        </section>

        <!-- Login form -->
        <section class="auth-card">

            <div class="login-card-icon" aria-hidden="true">✦</div>

            <h2>Welcome back!</h2>

            <p class="muted">
                Enter your account details to continue your journey.
            </p>

            <?php if ($error): ?>
                <div class="alert error" role="alert">
                    <?= e($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST" onsubmit="return validateLogin()">

                <label for="email">Email address</label>

                <input
                    type="email"
                    name="email"
                    id="email"
                    value="<?= e($email) ?>"
                    placeholder="you@example.com"
                    autocomplete="email"
                    required
                >

                <label for="password">Password</label>

                <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="Enter your password"
                    autocomplete="current-password"
                    required
                >

                <button class="btn primary full" type="submit">
                    Sign in to TalentSprint
                </button>

            </form>

            <p class="auth-bottom">
                Don't have an account?
                <a href="register.php">Create an account</a>
            </p>

            <div class="login-secure-note">
                <span>●</span>
                Your career journey starts here
            </div>

        </section>

    </div>

    <script src="js/validation.js"></script>

</body>
</html>