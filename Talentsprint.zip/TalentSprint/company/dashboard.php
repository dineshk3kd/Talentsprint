<?php
session_start();

require_once __DIR__ . '/../config/database.php';

require_role('company');

$data = db_load();

$company = db_company_by_user(
    $data,
    (int) $_SESSION['user_id']
);

$cid = (int) ($company['id'] ?? 0);

$roles = array_values(array_filter(
    $data['internships'],
    fn($i) => (int) $i['company_id'] === $cid
));

$apps = 0;

foreach ($data['applications'] as $a) {
    $i = db_internship($data, (int) $a['internship_id']);

    if ($i && (int) $i['company_id'] === $cid) {
        $apps++;
    }
}

$open = count(array_filter(
    $roles,
    fn($i) => $i['status'] === 'Open'
));

$flash = take_flash();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Company Dashboard · TalentSprint</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>
        /* All new styling is limited to this company dashboard. */

        body:has(.ts-company-dashboard) {
            --ts-bg: #07091b;
            --ts-panel: rgba(18, 23, 59, .88);
            --ts-cyan: #00e5ff;
            --ts-teal: #00f5c4;
            --ts-blue: #477bff;
            --ts-purple: #a855f7;
            --ts-pink: #ff45d4;
            --ts-orange: #ffae57;
            --ts-text: #f8faff;
            --ts-muted: #b4bfdc;

            background:
                radial-gradient(
                    ellipse at 10% 10%,
                    rgba(71, 123, 255, .18),
                    transparent 36%
                ),
                radial-gradient(
                    ellipse at 90% 25%,
                    rgba(168, 85, 247, .14),
                    transparent 34%
                ),
                radial-gradient(
                    ellipse at 50% 100%,
                    rgba(0, 245, 196, .09),
                    transparent 40%
                ),
                var(--ts-bg);

            color: var(--ts-text);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .ts-company-dashboard {
            position: relative;
            isolation: isolate;
            max-width: 1250px;
            margin: 0 auto;
            padding: 48px 28px 70px;
        }

        /* Background star field */

        .ts-space {
            position: fixed;
            inset: 0;
            z-index: -1;
            overflow: hidden;
            pointer-events: none;
        }

        .ts-space .star {
            position: absolute;
            width: 3px;
            height: 3px;
            border-radius: 50%;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 229, 255, .9);
            animation: ts-twinkle 3s ease-in-out infinite alternate;
        }

        .ts-space .star:nth-child(1) {
            top: 15%;
            left: 12%;
        }

        .ts-space .star:nth-child(2) {
            top: 30%;
            left: 82%;
            animation-delay: .7s;
        }

        .ts-space .star:nth-child(3) {
            top: 72%;
            left: 20%;
            animation-delay: 1.2s;
        }

        .ts-space .star:nth-child(4) {
            top: 85%;
            left: 77%;
            animation-delay: 1.8s;
        }

        .ts-space .star:nth-child(5) {
            top: 45%;
            left: 55%;
            animation-delay: 2.1s;
        }

        .ts-space .shooting-star {
            position: absolute;
            top: 15%;
            left: 100%;
            width: 115px;
            height: 2px;
            opacity: 0;
            transform: rotate(-35deg);
            transform-origin: right;
            background: linear-gradient(
                90deg,
                transparent,
                var(--ts-cyan),
                #fff
            );
            filter: drop-shadow(0 0 5px var(--ts-cyan));
            animation: ts-shoot 8s linear infinite;
        }

        .ts-space .shooting-star:nth-child(7) {
            top: 48%;
            animation-delay: 3s;
            animation-duration: 10s;
        }

        .ts-space .shooting-star:nth-child(8) {
            top: 75%;
            animation-delay: 5.5s;
            animation-duration: 9s;
        }

        @keyframes ts-twinkle {
            from {
                opacity: .3;
                transform: scale(.7);
            }
            to {
                opacity: 1;
                transform: scale(1.5);
            }
        }

        @keyframes ts-shoot {
            0% {
                left: 110%;
                opacity: 0;
            }
            5% {
                opacity: 1;
            }
            20% {
                left: -20%;
                opacity: 0;
            }
            100% {
                left: -20%;
                opacity: 0;
            }
        }

        /* Heading section */

        .ts-company-dashboard .page-heading {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 30px;
            padding: 32px;
            margin-bottom: 28px;
            border: 1px solid rgba(133, 156, 255, .22);
            border-radius: 25px;
            background:
                linear-gradient(
                    125deg,
                    rgba(71, 123, 255, .14),
                    rgba(168, 85, 247, .09),
                    rgba(0, 245, 196, .05)
                ),
                var(--ts-panel);
            box-shadow: 0 20px 65px rgba(0, 0, 0, .2);
            overflow: hidden;
        }

        .ts-company-dashboard .page-heading::after {
            content: "";
            position: absolute;
            width: 250px;
            height: 250px;
            top: -170px;
            right: 18%;
            border-radius: 50%;
            background: rgba(0, 229, 255, .09);
            filter: blur(30px);
            pointer-events: none;
        }

        .ts-company-dashboard .eyebrow {
            color: var(--ts-teal);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 3px;
            margin-bottom: 12px;
        }

        .ts-company-dashboard .page-heading h1 {
            margin: 0 0 12px;
            font-size: clamp(28px, 4vw, 43px);
            line-height: 1.15;
            font-weight: 800;
            overflow-wrap: anywhere;
            background: linear-gradient(
                90deg,
                #fff,
                var(--ts-cyan),
                var(--ts-purple),
                var(--ts-pink)
            );
            background-size: 200% auto;
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: ts-gradient 7s linear infinite;
        }

        @keyframes ts-gradient {
            to {
                background-position: 200% center;
            }
        }

        .ts-company-dashboard .page-heading p:not(.eyebrow) {
            color: var(--ts-muted);
            line-height: 1.8;
            margin: 0;
        }

        /* Post internship button */

        .ts-company-dashboard .btn.primary {
            position: relative;
            flex-shrink: 0;
            padding: 14px 22px;
            border: 0;
            border-radius: 13px;
            color: #071522;
            font-weight: 800;
            text-decoration: none;
            background: linear-gradient(
                100deg,
                var(--ts-teal),
                var(--ts-cyan),
                #8b9dff
            );
            box-shadow: 0 0 25px rgba(0, 229, 255, .17);
            transition: transform .25s ease, box-shadow .25s ease;
        }

        .ts-company-dashboard .btn.primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 0 32px rgba(0, 229, 255, .32);
        }

        /* Small Earth and orbiting Moon */

        .ts-orbit-widget {
            position: relative;
            width: 132px;
            height: 132px;
            flex: 0 0 132px;
            margin: 4px 15px 4px 0;
        }

        .ts-orbit-ring {
            position: absolute;
            inset: 13px 0;
            border: 1px solid rgba(0, 229, 255, .35);
            border-radius: 50%;
            transform: rotate(-25deg);
            box-shadow: 0 0 14px rgba(0, 229, 255, .06);
        }

        .ts-earth {
            position: absolute;
            width: 62px;
            height: 62px;
            top: 35px;
            left: 35px;
            border-radius: 50%;
            overflow: hidden;
            background:
                radial-gradient(
                    circle at 30% 25%,
                    rgba(255, 255, 255, .8),
                    transparent 12%
                ),
                radial-gradient(
                    ellipse at 30% 38%,
                    #6cf4ff 0 7%,
                    transparent 8%
                ),
                radial-gradient(
                    ellipse at 65% 60%,
                    #44e5a5 0 17%,
                    transparent 18%
                ),
                radial-gradient(
                    ellipse at 35% 68%,
                    #36d6a0 0 14%,
                    transparent 15%
                ),
                radial-gradient(
                    circle at 35% 30%,
                    #48cfff,
                    #1768d9 55%,
                    #081c6a 100%
                );
            border: 2px solid rgba(150, 246, 255, .85);
            box-shadow:
                0 0 15px rgba(0, 229, 255, .65),
                inset -8px -5px 12px rgba(0, 0, 50, .55);
            animation: ts-earth-glow 4s ease-in-out infinite alternate;
        }

        .ts-earth::after {
            content: "";
            position: absolute;
            top: 0;
            left: 5px;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: linear-gradient(
                90deg,
                transparent 35%,
                rgba(0, 0, 30, .45)
            );
        }

        .ts-moon-orbit {
            position: absolute;
            inset: 0;
            border-radius: 50%;
            animation: ts-orbit 6s linear infinite;
        }

        .ts-moon {
            position: absolute;
            top: 5px;
            left: 57px;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background: radial-gradient(
                circle at 30% 25%,
                #fff,
                #dce4f5 50%,
                #8d9ab9
            );
            box-shadow: 0 0 10px rgba(255, 255, 255, .65);
        }

        .ts-moon::before,
        .ts-moon::after {
            content: "";
            position: absolute;
            border-radius: 50%;
            background: rgba(111, 125, 153, .35);
        }

        .ts-moon::before {
            width: 4px;
            height: 4px;
            top: 4px;
            left: 3px;
        }

        .ts-moon::after {
            width: 3px;
            height: 3px;
            top: 9px;
            left: 8px;
        }

        @keyframes ts-orbit {
            from {
                transform: rotate(0deg);
            }
            to {
                transform: rotate(360deg);
            }
        }

        @keyframes ts-earth-glow {
            from {
                box-shadow:
                    0 0 10px rgba(0, 229, 255, .4),
                    inset -8px -5px 12px rgba(0, 0, 50, .55);
            }
            to {
                box-shadow:
                    0 0 22px rgba(0, 229, 255, .8),
                    inset -8px -5px 12px rgba(0, 0, 50, .55);
            }
        }

        /* Statistics */

        .ts-company-dashboard .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 20px;
            margin: 25px 0 35px;
        }

        .ts-company-dashboard .stat-card {
            position: relative;
            padding: 25px;
            border-radius: 20px;
            overflow: hidden;
            background: var(--ts-panel);
            border: 1px solid rgba(255, 255, 255, .1);
            transition: transform .25s ease, border-color .25s ease;
        }

        .ts-company-dashboard .stat-card::before {
            content: "";
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 4px;
            background: var(--ts-card-gradient);
        }

        .ts-company-dashboard .stat-card:nth-child(1) {
            --ts-card-gradient: linear-gradient(
                90deg,
                var(--ts-cyan),
                var(--ts-blue)
            );
        }

        .ts-company-dashboard .stat-card:nth-child(2) {
            --ts-card-gradient: linear-gradient(
                90deg,
                var(--ts-teal),
                #a3ff9e
            );
        }

        .ts-company-dashboard .stat-card:nth-child(3) {
            --ts-card-gradient: linear-gradient(
                90deg,
                var(--ts-purple),
                var(--ts-pink),
                var(--ts-orange)
            );
        }

        .ts-company-dashboard .stat-card:hover {
            transform: translateY(-5px);
            border-color: rgba(0, 229, 255, .45);
        }

        .ts-company-dashboard .stat-card span {
            display: block;
            color: var(--ts-muted);
            font-size: 14px;
            margin-bottom: 14px;
        }

        .ts-company-dashboard .stat-card strong {
            display: block;
            font-size: clamp(32px, 4vw, 43px);
            font-weight: 800;
            color: var(--ts-text);
        }

        /* Quick action cards */

        .ts-company-dashboard .quick-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 20px;
        }

        .ts-company-dashboard .quick-card {
            position: relative;
            min-height: 155px;
            padding: 26px;
            border-radius: 20px;
            text-decoration: none;
            background: var(--ts-panel);
            border: 1px solid rgba(133, 156, 255, .18);
            transition:
                transform .25s ease,
                border-color .25s ease,
                background .25s ease;
            overflow: hidden;
        }

        .ts-company-dashboard .quick-card::after {
            content: "↗";
            position: absolute;
            right: 22px;
            top: 20px;
            font-size: 22px;
            color: var(--ts-cyan);
            transition: transform .25s ease;
        }

        .ts-company-dashboard .quick-card:nth-child(1) {
            box-shadow: inset 0 3px 0 rgba(0, 229, 255, .75);
        }

        .ts-company-dashboard .quick-card:nth-child(2) {
            box-shadow: inset 0 3px 0 rgba(168, 85, 247, .8);
        }

        .ts-company-dashboard .quick-card:nth-child(3) {
            box-shadow: inset 0 3px 0 rgba(255, 69, 212, .8);
        }

        .ts-company-dashboard .quick-card:hover {
            transform: translateY(-6px);
            border-color: rgba(0, 229, 255, .45);
            background: rgba(23, 31, 76, .96);
        }

        .ts-company-dashboard .quick-card:hover::after {
            transform: translate(3px, -3px);
        }

        .ts-company-dashboard .quick-card h3 {
            margin: 12px 30px 12px 0;
            font-size: 19px;
            color: var(--ts-text);
        }

        .ts-company-dashboard .quick-card p {
            margin: 0;
            color: var(--ts-muted);
            font-size: 14px;
            line-height: 1.8;
        }

        /* Flash messages */

        .ts-company-dashboard .alert {
            padding: 15px 18px;
            margin: 0 0 20px;
            border-radius: 12px;
            background: rgba(18, 23, 59, .9);
            color: var(--ts-text);
        }

        .ts-company-dashboard .alert.success {
            border: 1px solid rgba(0, 245, 196, .45);
        }

        .ts-company-dashboard .alert.error {
            border: 1px solid rgba(255, 69, 212, .45);
        }

        @media (max-width: 900px) {
            .ts-company-dashboard .page-heading {
                flex-wrap: wrap;
            }

            .ts-company-dashboard .stats-grid,
            .ts-company-dashboard .quick-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .ts-company-dashboard .page-heading > .btn {
                width: fit-content;
            }
        }

        @media (max-width: 600px) {
            .ts-company-dashboard {
                padding: 25px 15px 45px;
            }

            .ts-company-dashboard .page-heading {
                padding: 23px;
                gap: 20px;
            }

            .ts-company-dashboard .stats-grid,
            .ts-company-dashboard .quick-grid {
                grid-template-columns: 1fr;
                gap: 14px;
            }

            .ts-orbit-widget {
                width: 105px;
                height: 105px;
                flex-basis: 105px;
            }

            .ts-orbit-ring {
                inset: 10px 0;
            }

            .ts-earth {
                width: 50px;
                height: 50px;
                top: 28px;
                left: 28px;
            }

            .ts-moon {
                left: 45px;
                top: 2px;
                width: 13px;
                height: 13px;
            }

            .ts-company-dashboard .btn.primary {
                width: 100%;
                text-align: center;
                box-sizing: border-box;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            .ts-company-dashboard *,
            .ts-space * {
                animation: none !important;
                transition: none !important;
            }
        }
    </style>
</head>

<body>

<?php include 'company_nav.php'; ?>

<div class="ts-space" aria-hidden="true">
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>
    <span class="shooting-star"></span>
    <span class="shooting-star"></span>
    <span class="shooting-star"></span>
</div>

<main class="dashboard ts-company-dashboard">

    <div class="page-heading">

        <div>
            <p class="eyebrow">✦ HIRING WORKSPACE</p>

            <h1>
                <?= e($company['company_name'] ?? $_SESSION['name']) ?>
            </h1>

            <p>
                Publish opportunities and manage candidates from one dashboard.
            </p>
        </div>

        <div class="ts-orbit-widget" aria-label="A small Earth with the Moon orbiting it">
            <div class="ts-orbit-ring"></div>
            <div class="ts-earth"></div>
            <div class="ts-moon-orbit">
                <div class="ts-moon"></div>
            </div>
        </div>

        <a class="btn primary" href="add_internship.php">
            + Post an internship
        </a>

    </div>

    <?php if ($flash): ?>
        <div class="alert <?= $flash['type'] === 'success' ? 'success' : 'error' ?>">
            <?= e($flash['message']) ?>
        </div>
    <?php endif; ?>

    <div class="stats-grid">

        <div class="stat-card">
            <span>✦ Roles posted</span>
            <strong><?= count($roles) ?></strong>
        </div>

        <div class="stat-card">
            <span>✧ Open roles</span>
            <strong><?= $open ?></strong>
        </div>

        <div class="stat-card">
            <span>✦ Total applicants</span>
            <strong><?= $apps ?></strong>
        </div>

    </div>

    <div class="quick-grid">

        <a class="quick-card" href="add_internship.php">
            <h3>Create opportunity</h3>
            <p>
                Publish a new internship with skills, duration and stipend.
            </p>
        </a>

        <a class="quick-card" href="internships.php">
            <h3>Manage roles</h3>
            <p>
                Review your listings and close roles when they are filled.
            </p>
        </a>

        <a class="quick-card" href="applicants.php">
            <h3>Review applicants</h3>
            <p>
                Move candidates through review, interview and selection.
            </p>
        </a>

    </div>

</main>

</body>
</html>